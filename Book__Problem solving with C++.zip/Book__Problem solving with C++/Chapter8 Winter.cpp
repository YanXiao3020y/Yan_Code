//Yan Xiao
//12/16/18 (started)
//12/19/18 (finished)
//Winter break for practice
//Chapter 8

#include <iostream>
#include <Windows.h>
#include <string>
#include <cstring>
#include <vector>

using namespace std;

void PracticeProgram1();
//Using only functions from cstring that can extract the name, age, and title into separate variables.

void PracticeProgram2();
//Using the class string to extract the fields, which has the same output as PracticeProgram1.

void PracticeProgram4();
//Testing for a function named firstLast2 that returns true if the vector starts or ends with the digit 2, otherwise return false.

void PracticeProgram5();
//Testing for a function named swapFrontBack that swaps the first element in the vector with the last emement in the vector and should check if the vector is empty or not.

void PracticeProgram7();
//This program changes user's fisrt and last name in Pig Latin.
//If the first letter is a consonant, move it to the end and add "ay" to the end. Otherwise, if it is a vowel, add "way" to the end.

void ProgrammingProject1();
//This program corrects a sentence to correct form expect proper names, and the sentence contains only one period at the end.
//Treats the line break as if it were a blank, in the sense that a line break and any number of blanks are compressed to a single blank.

void ProgrammingProject4();
//This program reads a person's name in the follwing format: first name, then middle name or initial, and then last name. 
//Output: lastName, firstName Middle_Initial.
//It should work the same and place a period after the middle initial even if the input did not contain a period.
//It should allow for users who give no middle name or middle initial.

void ProgrammingProject14();
//Implement the function split so that it returns a vector of the strings in target that are seperated by the string delimiter. 
//e.g. split("10,20,30", ",")
//it should return a vector with the strings "10", "20", and "30".

void ProgrammingProject15();
//This program use a function that determines if two strings are anagrams. 
//The function should not be case sensitive and should disregard any punctuation or spaces.

void ProgrammingProject18();
//This program inputs two strings that represents a time of day using the farmat HH:MM:SS AM|PM.
//And then ouput the time elapsed from the first to the second time in munutes and seconds.
//e.g.
//11:58:10 PM
//12:02:15 AM
//The output should be 4 minutes and 5 seconds.

void setColors(WORD tColor, WORD bColor)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), tColor + (bColor * 16));
}

void displayMenu()
{
	setColors(13, 0);
	cout << "\n\t" << char(201) << string(30, char(205)) << char(187) << "\n\t" << char(186);
	setColors(15, 1);
	cout << "          CHAPTER 8           ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(204) << string(30, char(205)) << char(185) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   1: Practice Proggram 1     ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   2: Practice Proggram 2     ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   3: Practice Proggram 4     ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   4: Practice Proggram 5     ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   5: Practice Proggram 7     ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   6: Programming Project 1   ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   7: Programming Project 4   ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   8: Programming Project 14  ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "   9: Programming Project 15  ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(186);
	setColors(15, 4);
	cout << "  10: Programming Project 18  ";
	setColors(13, 0);
	cout << char(186) << "\n\t" << char(200) << string(30, char(205)) << char(188) << "\n";
	setColors(15, 0);
	cout << " \t  Option: ";
}

int main()
{
	while (true)
	{
		system("cls");
		displayMenu();
		char option[80];
		setColors(14, 0);
		cin.getline(option, 80, '\n');
		setColors(15, 0);

		switch (atoi(option))
		{
			case 1: PracticeProgram1(); break;
			case 2: PracticeProgram2(); break;
			case 3: PracticeProgram4(); break;
			case 4: PracticeProgram5(); break;
			case 5: PracticeProgram7(); break;
			case 6: ProgrammingProject1(); break;
			case 7: ProgrammingProject4(); break;
			case 8: ProgrammingProject14(); break;
			case 9: ProgrammingProject15(); break;
			case 10: ProgrammingProject18(); break;
		default: return 0;
		}
		system("pause");
	}

	return 0;
}

void PracticeProgram1()
{
	char aCString[50] = "";

	char ans;
	do
	{
		cout << "\nEnter a string which contains the following format and is separated by a space! \n(e.g. name age title): ";
		cin.getline(aCString, 20);
		cout << "You entered " << aCString << ". Is that correct? (Yes/No): ";
		cin >> ans;
		cin.ignore(999, '\n');
	} while (tolower(ans) != 'y');

	int firstSpace(0), secondSpace(0);

	for (int i = 0; i < strlen(aCString); i++)
	{
		if ((aCString[i] == ' ') && (firstSpace == 0) && (secondSpace == 0))
		{
			firstSpace = i;
			continue;
		}
		if ((aCString[i] == ' ') && (firstSpace != 0) && (secondSpace == 0))
			secondSpace = i;
	}

	//If the name too long, then change the size of name.
	const int SIZE_OF_NAME = 20;
	char name[SIZE_OF_NAME] = "", age[3+1] = "" , title[20] = "";
	if (firstSpace != 0)
	{
		for (int i = 0; i < firstSpace; i++)
			name[i] = aCString[i];
		name[firstSpace] = '\0';
	}
	else
		strncpy_s(name, aCString, SIZE_OF_NAME);

	int indexForAge = 0;
	if (secondSpace != 0)
	{
		for (int i = ++firstSpace; i < secondSpace; i++)
		{
			age[indexForAge] = aCString[i];
			indexForAge++;
		}
		age[indexForAge] = '\0';
	}
	else
	{
		for (int i = ++firstSpace; i < strlen(aCString); i++)
		{
			age[indexForAge] = aCString[i];
			indexForAge++;
		}
		age[indexForAge] = '\0';
	}

	bool isAge = true;
	for (int i = 0; i < strlen(age); i++)
	{
		if (!isdigit(age[i]))
			isAge = false;
	}
		
	int indexForTitle = 0;
	for (int i = ++secondSpace; i < strlen(aCString); i++)
	{
		title[indexForTitle] = aCString[i];
		indexForTitle++;
	}
	title[indexForTitle] = '\0';

	if(!strcmp(name, ""))
		cout << "ERROR-1A: Empty input.\n";
	else if (firstSpace == 1)
		cout << "\nName: " << name << endl;
	else if (!isAge)
		cout << "ERROR-1B: Wrong Age!\n";
	else if ((firstSpace != 0) && (secondSpace == 1))
	{
		cout << "\nName: " << name << endl;
		cout << "Age: " << age << endl;
	}
	else
	{
		cout << "\nName: " << name << endl;
		cout << "Age: " << age << endl;
		cout << "Title: " << title << endl;
	}

	cin.ignore();
}

void PracticeProgram2()
{
	string aString;

	char ans;
	do
	{
		cout << "\nEnter a string which contains the following format and is separated by a space! \n(e.g. name age title): ";
		getline(cin, aString);
		cout << "You entered " << aString << ". Is that right? (yes/no): ";
		cin >> ans;
		cin.ignore(999, '\n');
	} while (tolower(ans) != 'y');

	int firstSpace(0), secondSpace(0);
	firstSpace = aString.find(' ');
	secondSpace = aString.find(' ', firstSpace + 1);
	cout << firstSpace << " " << secondSpace << endl;

	string name, age, title;
	if (aString.empty())
		cout << "ERROR-2A: Empty input!\n";
	else
	{
		if (firstSpace == -1)
			name = aString;
		else if ((firstSpace != -1) && (secondSpace == -1))
		{
			name = aString.substr(0, firstSpace);
			age = aString.substr(firstSpace + 1, aString.length() - firstSpace - 1);
		}
		else
		{
			name = aString.substr(0, firstSpace);
			age = aString.substr(firstSpace + 1, secondSpace - firstSpace - 1);
			title = aString.substr(secondSpace + 1, aString.length() - secondSpace - 1);
		}

		bool isAge = true;
		for (int i = 0; i < age.length(); i++)
			if (!isdigit(age[i]))
				isAge = false;

		if (age.empty())
			cout << "\nName: " << name << endl;
		else if (!isAge)
			cout << "ERROR-2B: Wrong Age!\n";
		else if (title.empty())
			cout << "\nName: " << name
			<< "\nAge: " << age << endl;
		else
			cout << "\nName: " << name
			<< "\nAge: " << age
			<< "\nTitle: " << title << endl;
	}

	cin.ignore();
}

bool firstLast2(vector<int> test)//Returns true if the vector starts or ends with the digit 2, otherwise return false.
{
	return((test[0] == 2) || (test[test.size() - 1] == 2));
}
void PracticeProgram4()
{
	vector<int> test;

	cout << "\nEnter a list of integer \n('-1' used to end the list): ";
	int x;
	cin >> x;
	while (x != -1)
	{
		test.push_back(x);
		cin >> x;
	}

	if (test.empty())
		cout << "ERROR-4A: Empty Input!\n";
	else
	{
		if (firstLast2(test))
			cout << "Yes, it contains 2 at first or last.\n";
		else
			cout << "No, 2 does not exit at first or last.\n";
	}

	cin.ignore();
}

bool swapFrontBack(vector<int>& test)//Swaps the first element in the vector with the last emement in the vector and should check if the vector is empty or not.
{
	if (test.empty())
		return false;

	int x = test[0];
	test[0] = test[test.size() - 1];
	test[test.size() - 1] = x;
	return true;
}
void PracticeProgram5()
{
	vector<int> test;

	cout << "\nEnter a list of integer \n('-1' used to end the list): ";
	int x;
	cin >> x;
	while (x != -1)
	{
		test.push_back(x);
		cin >> x;
	}

	if (!swapFrontBack(test))
		cout << "\nERROR-5A: Empty Input!\n";
	else
	{
		cout << "After swapFrontBack function, the vector is: ";
		for (int i = 0; i < test.size(); i++)
			cout << test[i] << " ";
		cout << endl;
	}

	cin.ignore();
}

void toLower(string& name)//Changes the character of the string to all lower letters.
{
	for (int i = 0; i < name.length(); i++)
		name[i] = tolower(name[i]);
}
void toUpper(string& name)//Changes the first character of the string to upper letter.
{
		name[0] = toupper(name[0]);
}
void toPigLatin(string& name)//If the first letter is a consonant, move it to the end and add "ay" to the end. Otherwise, if it is a vowel, add "way" to the end.
{
	string vowel = "aeiou";
	bool isVowel = false;
	for (int i = 0; i < vowel.size(); i++)
		if (name[0] == vowel[i])
		{
			name += "way";
			isVowel = true;
			break;
		}

	if (!isVowel)
	{
		char fCName = name[0];//The first character of name.
		int j(0);
		for (int i = 0; i < name.size() - 1; i++)
			name[i] = name[++j];
		name[j] = fCName;
		name += "ay";
	}
}
void PracticeProgram7()
{
	cout << "\nEnter your first name and last name (Seperate by a space): ";
	string firstN, lastN;
	cin >> firstN >> lastN;

	toLower(firstN);
	toLower(lastN);

	toPigLatin(firstN);
	toPigLatin(lastN);

	toUpper(firstN);
	toUpper(lastN);
	string fullName = firstN + " " + lastN;
	cout << "Your full name in Pig Latin is " << fullName  << ".\n";

	cin.ignore();
}

void compress(string& sentence)//Any number of blanks are compressed to a single blank.
{
	for (int i = 0; i < sentence.length(); i++)
	{
		int k = i;
		k++;
		if ((sentence[i] == ' ') && (sentence[k] == ' '))
		{
			for (int j = i; j < sentence.length()-1; j++)
			{
				int k = j;
				k++;
				sentence[j] = sentence[k];
			}
			sentence.erase(sentence.length() - 1, 1);
			i--;
		}
	}
}
void breakToBlank(string& sentence)//Changes a line break to a blank.
{
	for (int i = 0; i < sentence.length(); i++)
		if (sentence[i] == '\n')
			sentence[i] = ' ';
}
void ProgrammingProject1()
{
	cout << "Enter a sentence which has 100 characters (Only place a period at the end): ";
	string sentence;
	getline(cin, sentence, '.');

	toLower(sentence);
	toUpper(sentence);

	breakToBlank(sentence);

	compress(sentence);

	cout << "\nSentence: \n" << sentence << ".\n";

	cin.ignore();
}

void ProgrammingProject4()
{
	cout << "\nEnter a person's name in this format (firstName middlenameOrMiddle_Initial lastName): ";
	string firstName, middleName, lastName;
	cin >> firstName >> middleName;
	getline(cin, lastName);
	
	string middleInitial = "  ";
	middleInitial[0] = toupper(middleName[0]);
	middleInitial[1] = '.';

	cout << "Output: ";
	if (lastName.empty())
	{
		lastName = middleName;
		cout << lastName << ", " << firstName << endl;
	}
	else
		cout << lastName << ", " << firstName << " " << middleInitial << endl;


	cin.ignore();
}

vector<string> split(string target, string delimiters)//Returns a vector of the strings in target that are seperated by the string delimiter.
//e.g. split("10,20,30", ",")
//it should return a vector with the strings "10", "20", and "30".

{
	vector<string> split2;
	int k = 0;
	string partOfTarget;
	for (int i = 0; i < target.length(); i++)
	{
		for (int j = 0; j < delimiters.length(); j++)
		{
			if (target[i] == delimiters[j])
			{
				partOfTarget = target.substr(k, i - k);
				k = i;
				k++;
				split2.push_back(partOfTarget);
			}
		}
	}
	partOfTarget = target.substr(k, target.size() - k);
	split2.push_back(partOfTarget);

	return split2;
}
void ProgrammingProject14()
{
	cout << "\nEnter your target string: ";
	string target, delimiters;
	getline(cin, target);
	cout << "\nEnter your delimiters: ";
	getline(cin, delimiters);

	vector<string> split0 = split(target, delimiters);

	cout << "Output: ";
	for (int i = 0; i < split0.size(); i++)
	{
		cout << split0[i] << " ";
	}

	cout << endl;

	cin.ignore();
}

bool anagrams(string str1, string str2)//Determines if two strings are anagrams. 
{
	return (str1 == str2);
}
void order(string& str)//Rearranges the order of characters.
{
	for (int i = 0; i < str.length(); i++)
	{
		for (int j = i + 1; j < str.length(); j++)
		{
			if (str[i] > str[j])
			{
				char temp = str[i];
				str[i] = str[j];
				str[j] = temp;
			}
		}
	}
}
void readCharacters(string& str)//Disgards any punctuation or spaces.
{
	for (int i = 0; i < str.length(); i++)
		if (!isalpha(str[i]))
		{
			str.erase(i, 1);
			i--;
		}
}
void ProgrammingProject15()
{
	cout << "\nEnter the first string: ";
	string str1, str2;
	getline(cin, str1);
	cout << "\nEnter the second string: ";
	getline(cin, str2);

	toLower(str1);
	toLower(str2);

	readCharacters(str1);
	readCharacters(str2);

	order(str1);
	order(str2);

	if (anagrams(str1, str2))
		cout << "\nYes, they are.\n";
	else
		cout << "\nNo, they are not.\n";

	cout << str1 << endl << str2;

	cin.ignore();
}

void convert(int& hours, int& minutes, int& seconds, string& AM_PM, string time)//Converts the string of time to the integer of hours, minutes, seconds and the string or AM_PM.
{
	//Converts into hours.
	int firstColon = time.find(':');
	string hoursString = time.substr(0, firstColon);
	hours = stoi(hoursString);

	//Converts into minutes.
	int secondColon = time.find(':', firstColon + 1);
	string minuteString = time.substr(firstColon + 1, secondColon - firstColon - 1);
	minutes = stoi(minuteString);

	//Converts into AM_PM.
	int space = time.find(' ');
	AM_PM = time.substr(space + 1, 2);

	//converts into second.
	string secondString = time.substr(secondColon + 1, space - secondColon - 1);
	seconds = stoi(secondString);
}
int calculateToSecond(int hours, int minutes, int seconds, string AM_PM)//Calculate the time to total seconds.
{
	int totalSecond;
	if (AM_PM == "AM")
	{
		if (hours == 12)
			hours = 0;
		totalSecond = hours * 60 * 60 + minutes * 60 + seconds;
	}
	else 
		totalSecond = (hours + 12) * 60 * 60 + minutes * 60 + seconds;

	return totalSecond;
}
void calculateBackTime(int& hours, int& minutes, int& seconds, int diffOfSecond)//Converts total second back to hours, minutes, and seconds.
{
	hours = diffOfSecond / 3600;
	minutes = diffOfSecond % 3600 / 60;
	seconds = diffOfSecond % 3600 % 60;
}
void output(int hours, int minutes, int seconds)//Outputs different options. 
{
	cout << "The time elapsed is ";
	if ((hours != 0) && (minutes != 0) && (seconds != 0))
		cout << hours << " hours, " << minutes << " minutes and " << seconds << " seconds.";
	else if ((hours == 0) && (minutes != 0) && (seconds != 0))
		cout << minutes << " minutes and " << seconds << " seconds.";
	else if ((hours != 0) && (minutes == 0) && (seconds != 0))
		cout << hours << " hours and " << seconds << " seconds.";
	else if ((hours != 0) && (minutes != 0) && (seconds == 0))
		cout << hours << " hours and " << minutes << " minutes.";
	else if ((hours != 0) && (minutes == 0) && (seconds == 0))
		cout << hours << " hours.";
	else if ((hours == 0) && (minutes != 0) && (seconds == 0))
		cout << minutes << " minutes.";
	else if ((hours == 0) && (minutes == 0) && (seconds != 0))
		cout << seconds << " seconds.";

	cout << endl;
}
void ProgrammingProject18()
{
	string first, second;
	cout << "\nThe following format for time: HH:MM:SS AM|PM (e.g 11:58:10 PM) (12:02:15 AM):\n"
		<< "Enter your first time: ";
	getline(cin, first);
	cout << "Enter your second time: ";
	getline(cin, second);

	int hours1, minutes1, seconds1;//For the time first.
	int hours2, minutes2, seconds2;//For the time second.
	string AM_PM_1, AM_PM_2;//For the time first and second.

	convert(hours1, minutes1, seconds1, AM_PM_1, first);
	convert(hours2, minutes2, seconds2, AM_PM_2, second);

	int totalSecondOfF = calculateToSecond(hours1, minutes1, seconds1, AM_PM_1);
	int totalSecondOfS = calculateToSecond(hours2, minutes2, seconds2, AM_PM_2);

	if ((AM_PM_1 == "PM") && (AM_PM_2 == "AM"))
		totalSecondOfS += 24 * 3600;
	int difference = totalSecondOfS - totalSecondOfF;
	
	int hours, minutes, seconds;//Elapsed time
	calculateBackTime(hours, minutes, seconds, difference);

	output(hours, minutes, seconds);

	cin.ignore();
}