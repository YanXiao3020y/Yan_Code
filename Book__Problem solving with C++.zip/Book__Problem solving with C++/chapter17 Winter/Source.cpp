//Yan Xiao
//01/02/19 (started)
//01/03/19 (finisted)
//Winter practice
//Chapter 17

#include <iostream>
#include "Input.h"
#include "GenericList.h"
#include "vectorTemplate.h"
using namespace std;

void PracticeProgram1();
//Testing the template function search().

void ProgrammingProject1();
//Testing the template class GenericList.

void ProgrammingProject2();
//Testing the member function findValue() in class GenericList.

void ProgrammingProject4();
//Testing the function sort().

void ProgrammingProject7();
//Testing the template class VectorTemplate, except the requirement 'e' condition.

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\t\tChapter 17\n";
		cout << "\t\t=====================================\n";
		cout << "\t\t\t 1: Practice Program1\n";
		cout << "\t\t\t 2: Programming Project1\n";
		cout << "\t\t\t 3: Programming Project2\n";
		cout << "\t\t\t 4: Programming Project4\n";
		cout << "\t\t\t 5: Programming Project7\n";
		cout << "\t\t=====================================\n";
		cout << "\t\t option: ";

		char option[80];
		cin.getline(option, 80, '\n');

		switch (atoi(option))
		{
		case 1: PracticeProgram1(); break;
		case 2: ProgrammingProject1(); break;
		case 3: ProgrammingProject2(); break;
		case 4: ProgrammingProject4(); break;
		case 5: ProgrammingProject7(); break;
		default: return 0;
		}
		system("pause");
	}
	return 0;
}

template<class T>
int search(const T a[], int numberUsed, T theValue)//Not suitable for double
{
	for (int i = 0; i < numberUsed; i++)
		if (a[i] == theValue)
			return i;
	return -1;
}
void PracticeProgram1()
{
	using namespace Validation;

	const int SIZE = 10;
	char a[SIZE];
	int numberUsed = 5;
	for (int i = 0; i < numberUsed; i++)
		a[i] = i + 'a';

	cout << "The array are ";
	for (int i = 0; i < numberUsed; i++)
		cout << a[i] << " ";
	cout << ".\n";

	char theValue;
	cout << "\nEnter the value: ";
	cin >> theValue;
	int index = search(a, numberUsed, theValue);
	if (index == -1)
		cout << "\nThe value, " << theValue << ", does not exist in the array.\n";
	else
		cout << "\nThe value, " << theValue << ", is the index of " << index << ".\n";
	

	cout << endl;
	cin.ignore();
}

void ProgrammingProject1()
{
	GenericList<int> list1, list2(5);

	int size = 5;
	for (int i = 0; i < size; i++)
		list2.add(i);
	cout << "list2.full? " << (list2.full() ? "Yes\n" : "No\n");
	cout << "list2: " << list2;

	list2.erase();
	cout << "list2.full? " << (list2.full() ? "Yes\n" : "No\n");
	cout << "list2: " << list2;

	GenericList<int> list3(10);
	int size1 = 10;
	for (int i = 0; i < size1; i++)
		list3.add(i);
	cout << "list3: " << list3;

	list3.next();
	list3.next();
	cout << "list3.getCurrentItem(): " << list3.getCurrentItem() << endl;
	list3.previous();
	cout << "list3.getCurrentItem(): " << list3.getCurrentItem() << endl;
	list3.reset();
	cout << "list3.getCurrentItem(): " << list3.getCurrentItem() << endl;

	cout << "list3.getItem(9): " << list3.getItem(9) << endl;

	cin.ignore();
}

void ProgrammingProject2()
{
	GenericList<int> list1, list2(5);

	int size = 5;
	for (int i = 0; i < size; i++)
		list2.add(i);
	cout << list2;

	int theItem = 1;
	int index = findValue(list2, theItem);
	if (index == -1)
		cout << "\nThe value, " << theItem << ", does not exist in the array.\n";
	else
		cout << "\nThe value, " << theItem << ", is the index of " << index << ".\n";

	cin.ignore();
}

template<class T>
void swapValues(T& i, T& j)
{
	T temp = i;
	i = j;
	j = temp;
}
template<class T>
void sort(T a[], int MAX_SIZE)
{
	for (int i = 0; i < MAX_SIZE; i++)
	{
		int k = 0;
		for (int j = i - 1; j >= 0; j--)
		{
			if (a[j] > a[i - k])
			{
				swapValues(a[j], a[i - k]);
				k++;
			}
		}
	}
}
void ProgrammingProject4()
{
	const int MAX_SIZE = 10;
	int arr[MAX_SIZE];
	int numberUsed = 3;
	
	for (int i = MAX_SIZE - 1; i >= 0; i--)
		arr[MAX_SIZE - 1 -i] = i;

	for (int i = 0; i < numberUsed; i++)
		cout << arr[i] << " ";
	cout << endl;

	sort(arr, numberUsed);
	for (int i = 0; i < numberUsed; i++)
		cout << arr[i] << " ";
	cout << endl;

	cin.ignore();
}

void ProgrammingProject7()
{
	VectorTemplate<int> test;

	int size = 5;
	for (int i = 0; i < size; i++)
		test.addItem(i);

	cout << "test: " << test;
	cout << "test == test: " << (test == test ? "Yes.\n" : "No.\n");

	VectorTemplate<int> test1;
	cout << "test.exist(3): " << (test.exist(3)? "Yes.\n":"No.\n");
	test1 = test.remove(3);
	cout << "test1.exist(3): " << (test1.exist(3) ? "Yes.\n" : "No.\n");
	cout << "test: " << test
		<< "test1.getSize(): " << test1.getSize() << endl;


	cout << "test1 == test: " << (test1 == test? "Yes.\n" : "No.\n");
	test1.addItem(3);
	cout << "test1 == test: " << (test1 == test ? "Yes.\n" : "No.\n");


	cin.ignore();
}
