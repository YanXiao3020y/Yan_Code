#ifndef GENERICLIST_H
#define GENERICLIST_H

#include <iostream>
using namespace std;

template<class ItemType>
class GenericList
{
private:
	ItemType *item;//pointer to the dynamic array that holds the list.
	int maxLength;//max number of items allowed on the list.
	int currentLength;//number of items currently on the list.
	int current;//Records the position on the list of the current item.
public:
	~GenericList();

	GenericList();

	GenericList(int theMaxLength);

	int length() const;

	bool full() const;
	
	void add(ItemType newItem);

	void erase();
	//Removes all items from the list so that the list is empty.

	friend ostream& operator << <>(ostream& outs, const GenericList<ItemType>& theObject);

	ItemType getCurrentItem() const;
	//Returns the current item as a value.

	void next();
	//Makes the next item the current item.

	void previous();
	//Makes the previous item the current item.

	void reset();
	//Makes the first item on the list the current item

	ItemType getItem(int n);
	//Returns the nth item on the list 

	template<class ItemType>
	friend int findValue(const GenericList<ItemType>& list, ItemType theItem);
	//Returns the position of the first occurrence of that item if found; otherwise, retruns -1.
	
};

template<class ItemType>
GenericList<ItemType>::~GenericList()
{
	delete[] item;
}

template<class ItemType>
GenericList<ItemType>::GenericList() : item(NULL), maxLength(0), currentLength(0), current(0)
{}

template<class ItemType>
GenericList<ItemType>::GenericList(int theMaxLength) : maxLength(theMaxLength), currentLength(0), current(0)
{
	item = new ItemType[maxLength];
}

template<class ItemType>
int GenericList<ItemType>::length() const
{
	return currentLength;
}

template<class ItemType>
bool GenericList<ItemType>::full() const
{
	return (currentLength == maxLength);
}

template<class ItemType>
void GenericList<ItemType>::add(ItemType newItem)
{
	if (full())
	{
		cout << "\nERROR-2A: Add to a full list!\n";
		cin.ignore();
	}

	item[currentLength++] = newItem;
}

template<class ItemType>
void GenericList<ItemType>::erase()//Removes all items from the list so that the list is empty.
{
	delete[] item;
	currentLength = 0;
	current = 0;
	item = new ItemType[maxLength];
}

template<class ItemType>
ostream& operator << <>(ostream& outs, const GenericList<ItemType>& theObject)
{
	for (int i = 0; i < theObject.currentLength; i++)
		outs << theObject.item[i] << " ";
	outs << endl;
	return outs;
}

template<class ItemType>
ItemType GenericList<ItemType>::getCurrentItem() const//Returns the current item as a value.
{
	return item[current];
}

template<class ItemType>
void GenericList<ItemType>::next()//Makes the next item the current item.
{
	if (current < currentLength - 1)
		current++;
}

template<class ItemType>
void GenericList<ItemType>::previous() //Makes the previous item the current item.
{
	if (current > 0)
		current--;
}

template<class ItemType>
void GenericList<ItemType>::reset()//Makes the first item on the list the current item
{
	current = 0;
}

template<class ItemType>
ItemType GenericList<ItemType>::getItem(int n) //Returns the nth item on the list 
{
	return item[n];
}

template<class ItemType>
int findValue(const GenericList<ItemType>& list, ItemType theItem)//Returns the position of the first occurrence of that item if found; otherwise, retruns -1.
{
	for (int i = 0; i < list.length(); i++)
		if (list.item[i] == theItem)
			return i;
	return -1;
}
#endif 