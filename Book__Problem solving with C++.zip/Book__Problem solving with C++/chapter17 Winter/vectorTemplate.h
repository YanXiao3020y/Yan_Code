#ifndef VECTORTEMPLATE_H
#define VECTORTEMPLATE_H

#include <vector>
#include <iostream>
using namespace std;

template<class T>
class VectorTemplate
{
private:
	vector<T> v;//A collection of items.
	int size;
public:
	VectorTemplate();

	VectorTemplate(int theSize);


	void addItem(T newItem);
	//Adds a new item to the set. If the item is already in the set, then nothing happens.

	VectorTemplate remove(int index);
	//Removes a specific item from the set. Not check for validation.

	int getSize() const;

	bool exist(T theItem);
	//Determines if an item is a member of the set.

	friend bool operator == <>(const VectorTemplate& v1, const VectorTemplate& v2);

	vector<T> vector() const;

	friend ostream& operator << <>(ostream& outs, const VectorTemplate<T>& theObject);
	
};

template<class T>
VectorTemplate<T>::VectorTemplate() : size(0)
{}

template<class T>
VectorTemplate<T>::VectorTemplate(int theSize) : size(theSize)
{}

template<class T>
void VectorTemplate<T>::addItem(T newItem)//Adds a new item to the set. If the item is already in the set, then nothing happens.
{
	bool noFound = true;
	for (int i = 0; i < size; i++)
		if (v[i] == newItem)
			noFound = false;
	if (noFound)
		v.push_back(newItem);
	size++;
}

template<class T>
VectorTemplate<T> VectorTemplate<T>::remove(int index)//Removes a specific item from the set. Not check for validation.
{
	VectorTemplate temp(size - 1);
	int k = 0;
	for (int i = 0; i < size; i++)
		if (i != index)
			temp.v.push_back(v[i]);
	return temp;
}

template<class T>
int VectorTemplate<T>::getSize() const
{
	return size;
}

template<class T>
bool VectorTemplate<T>::exist(T theItem) //Determines if an item is a member of the set.
{
	for (int i = 0; i < size; i++)
		if (v[i] == theItem)
			return true;
	return false;
}

template<class T>
bool operator ==(const VectorTemplate<T>& v1, const VectorTemplate<T>& v2)
{
	if (v1.size != v2.size)
		return false;
	for (int i = 0; i < v1.size; i++)
		if (v1.v[i] != v2.v[i])
			return false;
	return true;
}

template<class T>
vector<T> VectorTemplate<T>::vector() const
{
	return v;
}

template<class T>
ostream& operator << <>(ostream& outs, const VectorTemplate<T>& theObject)
{
	for (int i = 0; i < theObject.size; i++)
		outs << theObject.v[i] << " ";
	outs << endl;
	return outs;
}
#endif 