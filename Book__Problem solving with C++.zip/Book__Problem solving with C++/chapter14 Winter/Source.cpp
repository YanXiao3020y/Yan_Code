//Yan Xiao
//01/03/19 (started)
//01/04/19 (finished)
//Winter practice
//Chapter 14

#include <iostream>
#include <string>
using namespace std;

void PracticeProgram1();
//Testing the recursive function Fibonacci().

void PracticeProgram5();
//Testing the recursive function Palindrome().

void ProgrammingProject1();
//Testing the recursive function factorial().

void ProgrammingProject4();
//Testing the recursive function sort().

void ProgrammingProject5();
//Testing the recursive function Disk(), which is for Towers of Hanoi.

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\tChapter 14\n";
		cout << "\t\t=============================\n";
		cout << "\t\t 1: Practice Program1\n";
		cout << "\t\t 2: Practice Program5\n";
		cout << "\t\t 3: Programming Project1\n";
		cout << "\t\t 4: Programming Project4\n";
		cout << "\t\t 5: Programming Project5\n";
		cout << "\t\t=============================\n";
		cout << "\t\t option: ";

		char option[80];
		cin.getline(option, 80, '\n');

		switch (atoi(option))
		{
		case 1: PracticeProgram1(); break;
		case 2: PracticeProgram5(); break;
		case 3: ProgrammingProject1(); break;
		case 4: ProgrammingProject4(); break;
		case 5: ProgrammingProject5(); break;
		default: return 0;
		}
		system("pause");
	}
	return 0;
}

int Fibonacci(int n)//Returns the nth Fibonacci number.
{
	if (n == 1 || n == 0)
		return 1;
	else
	{
		return Fibonacci(n - 1) + Fibonacci(n - 2);
	}
}
void PracticeProgram1()
{
	int size = 10;
	cout << "\nThe first " << size << " Fibonacci numbers: ";
	for (int i = 0; i < size; i++)
		cout << Fibonacci(i) << " ";
	cout << endl;

	cin.ignore();
}

bool Palindrome(string input, int first, int last)
{
	if (first >= last)//Includes a single character.
		return true;
	if (input[first] != input[last])
		return false;
	return Palindrome(input, first + 1, last - 1);
}
void PracticeProgram5()
{
	string input;
	cout << "\nEnter a string: ";
	cin >> input;

	cout << "\nPalindrome? " << (Palindrome(input, 0, input.length() - 1)? "Yes.\n":"No.\n") << endl;


	cin.ignore();
}

int factorial(int n)//Decreases by one.
{
	if (n == 1)
		return 1;
	else
		return factorial(n - 1)*n;
}
void ProgrammingProject1()
{
	cout << "\nC(n,r) = n!/(r!*(n-r)!\n";
	int n = 10, r = 5;
	int result = factorial(n) / (factorial(r)*factorial(n - r));
	cout << "C(" << n << "," << r << ") = " << result << endl;

	cin.ignore();
}

void swapValues(int& v1, int& v2)
{
	int temp = v1;
	v1 = v2;
	v2 = temp;
}
void sort(int arr[], int size, int startIndex)
{
	if (startIndex == size - 1)
		return;
	else
	{
		int smallest = arr[startIndex];
		int smallestIndex = startIndex;
		for (int i = startIndex + 1; i < size; i++)
			if (arr[i] < smallest)
			{
				smallestIndex = i;
				smallest = arr[i];
			}
		if (smallestIndex != startIndex)
			swapValues(arr[startIndex], arr[smallestIndex]);
		sort(arr, size, startIndex + 1);
	}
	
	
}
void ProgrammingProject4()
{
	const int SIZE = 6;
	int a[SIZE];

	int j = 0;
	for (int i = SIZE; i > 0; i--)
		a[j++] = i;

	for (int i = 0; i < SIZE; i++)
		cout << a[i] << " ";
	cout << endl;
	
	sort(a, SIZE, 0);
	for (int i = 0; i < SIZE; i++)
		cout << a[i] << " ";
	cout << endl;

	cin.ignore();
}

void Disk(int n, int first, int second, int third)
{
	if (n == 1)
		cout << "Move Disk " << n << " from post " << first << " to post " << second << ".\n";
	else
	{
		Disk(n - 1, first, third, second);
		cout << "Move Disk " << n << " from post " << first << " to post " << second << ".\n";
		Disk(n - 1, third, second, first);
	}
}
void ProgrammingProject5()
{
	cout << "\nEnter a integer: ";
	int i;
	cin >> i;
	Disk(i, 1, 2, 3);

	cin.ignore();
}

