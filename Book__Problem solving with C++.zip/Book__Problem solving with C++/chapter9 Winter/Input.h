#ifndef INPUT_H
#define INPUT_H
#include <iostream>
#include <string>
using namespace std;

namespace Validation
{
	int inputInteger(string prompt);
	//Returns an input integer.

	int inputInteger(string prompt, int number);
	//Returns an input integer except the specific number.

	int inputInteger(string prompt, bool posNeg);
	//Returns an integer where posNeg is positive (true) or negative (false).

	int inputInteger(string prompt, bool greaterLess, int theNumber);
	//Returns an integer which is great (true) or less (false) than a number. And theNumber is not in the range to be outputed.

	int inputInteger(string prompt, int startRange, int endRange);
	//Returns an input integer within range--start and end.

	double inputDouble(string prompt);
	//Returns an input double.

	double inputDouble(string prompt, bool posNeg);
	//Returns a double where posNeg is positive (true) or negative (false).

	double inputDouble(string prompt, double startRange, double endRange);
	//Returns an input double within range--start and end.

	char inputCharacter(string prompt);
	//Returns an input, which only accepts letter.

}

#endif