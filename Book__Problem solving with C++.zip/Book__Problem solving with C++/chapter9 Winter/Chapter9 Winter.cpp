//Yan Xiao
//12/20/18 (started)
//12/21/18 (finished)
//Winter break for practice
//Chapter 9

#include <iostream>
#include <iomanip>
#include <vector>
#include "Input.h"

using namespace std;
using namespace Validation;

void Program_Project3();
//This program will assign passengers seats in an airplane. 
//It should display the seat pattern, with an X marking the seats alrady assigned. 
//It continues until all seats are filled or until the user signals that the program should end.
//If the user types in a seat that is alrady assigned, then program should say that the seat is ocuupied and ask for another choice.

void Program_Project4();
//Takes a C string as an input parameter and reverses the strings.

void Program_Project6();
//Testing the function addEntry and deleteEntry.

void Program_Project7();
//This program emulates two-dimensional arrays by building one-dimensional array.
//Testing the functions create2DArray, set, and get.

void Program_Project8();
//Outputs a histogram of student grades for an assignment.

void Practice_Program1();
//Testing for the function addOne, which is incremented by 1.

void Practice_Program2();
//Calculate the average of a series of input which is the type of double.

void Practice_Program3();
//Returns true if the string cstr is a palindrome, otherwise, returns false.

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\tChapter 9" << endl;
		cout << "\t=========================================" << endl;
		cout << " \t\t1: Programming Project3" << endl;
		cout << " \t\t2: Programming Project4" << endl;
		cout << " \t\t3: Programming Project6" << endl;
		cout << " \t\t4: Programming Project7" << endl;
		cout << " \t\t5: Programming Project8" << endl;
		cout << " \t\t6: Practice Program1" << endl;
		cout << " \t\t7: Practice Program2" << endl;
		cout << " \t\t8: Practice Program3" << endl;

		cout << "\t=========================================" << endl;
		cout << " \toption: ";
		char option[80];
		cin.getline(option, 80, '\n');
		cout << endl;
		switch (atoi(option))
		{
		case 1: Program_Project3(); break;
		case 2: Program_Project4(); break;
		case 3: Program_Project6(); break;
		case 4: Program_Project7(); break;
		case 5: Program_Project8(); break;
		case 6: Practice_Program1(); break;
		case 7: Practice_Program2(); break;
		case 8: Practice_Program3(); break;
		default: exit(0);
		}
		cout << endl;
		system("pause");
		cin.clear();
	}

	return 0;
}

void addOne(int *ptrNum)//Incremented by 1.
{
	*ptrNum += 1;
}
void Practice_Program1()
{
	int *ptrNum = new int;
	*ptrNum = inputInteger("\nEnter an integer: ");

	addOne(ptrNum);
	cout << "By addOne, the new value is " << *ptrNum << ".\n";

	delete ptrNum;

	cin.ignore();
}

void Practice_Program2()
{
	cout << "\nEnter an integer: ";
	int numDoubles;
	cin >> numDoubles;

	double *numDoublesPrt = new double[numDoubles];

	for (int i = 0; i < numDoubles; i++)
	{
		cout << "\nEnter the number " << i + 1 << ": ";
		cin >> numDoublesPrt[i];
	}

	double sum(0);
	for (int i = 0; i < numDoubles; i++)
		sum += numDoublesPrt[i];

	double avg = sum / numDoubles;

	cout << "\nThe average of these number is " << avg << ".\n";

	delete[] numDoublesPrt;

	cin.ignore();
}

bool isPalindrome(char *cstr) // Returns true if the string cstr is a palindrome, otherwise, return false.
{
	char *front = cstr;
	char *back = cstr + strlen(cstr) - 1;

	while (front < back)
	{
		if (*front != *back)
			return false;
		front++;
		back--;
	}
	return true;
}
void Practice_Program3()
{
	char s1[50] = "neveroddoreven";
	char s2[50] = "not a palindrome";
	cout << isPalindrome(s1) << endl;//true
	cout << isPalindrome(s2) << endl;//false

	cout << "s1: " << (isPalindrome(s1) ? " Yes.\n" : " No.\n");
	cout << "s2: " << (isPalindrome(s2) ? " Yes.\n" : " No.\n");

	cin.ignore();
}

void display(char *seat[], int ROW, int COLUMN)//Displays the graph.
{
	cout << endl;
	for (int i = 0; i < ROW; i++)
	{
		cout << i + 1 << " ";
		for (int j = 0; j < COLUMN; j++)
			cout << seat[i][j] << " ";
		cout << endl;
	}
}
void Program_Project3()
{
	const int ROW = inputInteger("\nEnter the number of rows that the plane has: ", true, 0);

	const int COLUMN = 4;
	//char **seat = new char *[row];//other form
	typedef char *CharArrayPtr;
	CharArrayPtr *seat = new CharArrayPtr[ROW];
	for (int i = 0; i < ROW; i++)
		seat[i] = new char[COLUMN];

	//Sets letters
	for (int i = 0; i < ROW; i++)
		for (int j = 0; j < COLUMN; j++)
			seat[i][j] = 'A' + j;

	//Output
	display(seat, ROW, COLUMN);

	int count = 0;//Counts total change.
	char ans;
	do
	{
		int row = inputInteger("\nEnter the row number: ", 1, ROW);
		char letter = toupper(inputCharacter("\nEnter the column letter: "));

		bool noExist = true;  //Checks whether the letter is already changed or not.
		do
		{
			for (int i = 0; i < COLUMN; i++)
				if ((seat[row - 1][i] == letter)&&(seat[row-1][i] != 'X'))
				{
					seat[row - 1][i] = 'X';
					noExist = false;
					count++;
					break;
				}

			if (!noExist)
				break;

			noExist = true;

			cout << "\nThe seat is already ocupied!\n\n\nPlease enter another one: \n";
			row = inputInteger("\nEnter the row number: ", 1, ROW);
			letter = toupper(inputCharacter("\nEnter the column letter: "));

			cin.ignore();
		} while (noExist);

		display(seat, ROW, COLUMN);

		if (count >= ROW * COLUMN)
		{
			cout << "\nAll seats are filled!\n";
			break;
		}

		cout << "\nDo you want to continue? (Y/N): ";
		cin >> ans;
		cin.ignore();
		
	} while (tolower(ans) == 'y');

	cout << "\nThis is the result: \n";
	display(seat, ROW, COLUMN);

	for (int i = 0; i < ROW; i++)
		delete[] seat[i];

	delete[] seat;

	cin.ignore();
}

void reverse(char aCString[])
{
	char *front = aCString;
	char *back = aCString + strlen(aCString) - 1;

	while (front < back)
	{
		char temp = *front;
		*front = *back;
		*back = temp;
		front++;
		back--;
	}
}
void Program_Project4()
{
	char aCString[100] = "";
	cout << "\nEnter a string: ";
	cin.getline(aCString, 100);
	reverse(aCString);

	cout << "reverse: " << aCString << endl;
}

string *addEntry(string *dynamicArray, int& size, string newEntry)//Creates a new dynamic array one element larger than dynamicArray, copy all emements from dynamicArray into the new array, add the new entry onto the end of the new array, increment size, delete dynamicArray,and return the new dynamic array.
{
	string *newDA = new string[++size];
	for (int i = 0; i < size - 1; i++)
		newDA[i] = dynamicArray[i];
	newDA[size - 1] = newEntry;

	delete[] dynamicArray;
	return newDA;
}
string *deleteEntry(string *dynamicArray, int& size, string entryToDelete)//Search dynamicArray for entryToDelete. If not found, return the unmodified dynamicArray. Otherwise, create a new dynamic array one element smaller than dynamicArray. Copy all elements except entryToDelete into the new array, delete dynamicArray, decrement size, and return the new dynamic array.
{
	bool found = false;
	for (int i = 0; i < size; i++)
		if (dynamicArray[i] == entryToDelete)
			found = true;

	if (!found)
		return dynamicArray;
	else
	{
		string *newDA = new string[--size];
		int index = 0;
		for (int i = 0; i < size + 1; i++)
			if (dynamicArray[i] != entryToDelete)
				newDA[index++] = dynamicArray[i];

		delete[] dynamicArray;
		return newDA;
	}
}
void Program_Project6()
{
	int size = 5;
	string *stringPtr = new string[size];

	for (int i = 0; i < size; i++)
		stringPtr[i] = 'a' + i;

	for (int i = 0; i < size; i++)
		cout << stringPtr[i] << " ";
	cout << endl;

	stringPtr = addEntry(stringPtr, size, "H");
	
	
	cout << "After addEntry: ";
	for (int i = 0; i < size; i++)
		cout << stringPtr[i] << " ";

	cout << endl;

	stringPtr = deleteEntry(stringPtr, size, "H");
	cout << "After deleteEntry('H'): ";
	for (int i = 0; i < size; i++)
		cout << stringPtr[i] << " ";

	cout << endl;

	stringPtr = deleteEntry(stringPtr, size, "h");
	cout << "After deleteEntry('h'): ";
	for (int i = 0; i < size; i++)
		cout << stringPtr[i] << " ";

	delete[] stringPtr;

	cin.ignore();
}

void display(int *arr, int rows, int columns)//Prints 2D array.
{
	int j = 1;
	for (int i = 0; i < rows * columns; i++)
	{
		if (i == j * columns)
		{
			cout << endl;
			j++;
		}
		cout << setw(15) << arr[i];
	}
}
int *create2DArray(int rows, int columns)//Return a poointer that points to a one-dimensional dynamic array which holds a two-dimensional array of size rows * columns.
{
	int sizeOfArray = rows * columns;
	int *intPtr = new int[sizeOfArray];

	return intPtr;
}
void set(int *arr, int rows, int columns, int desired_row, int desired_column, int val)//Stores val into the emulated two-dimensional array at position desired_row, desired_column. The desired_row and desired_column are the zero-based index of the row and column which the caller would like to access.
{
	if ((desired_row >= rows || desired_row < 0) || (desired_column >= columns || desired_column < 0))
	{
		cout << "ERROR-1A: desired_row or desired_column does not exist!\n";
		return;
	}
	int index = desired_row * columns + desired_column;
	arr[index] = val;

}
int get(int *arr, int rows, int columns, int desired_row, int desired_column)//Returns the value in the emulated two-dimensional array at position desired_row, desired_column.
{
	if ((desired_row >= rows || desired_row < 0) || (desired_column >= columns || desired_column < 0))
	{
		cout << "ERROR-1A: desired_row or desired_column does not exist!\n";
		exit(1);
	}
	int index = desired_row * columns + desired_column;
	
	return arr[index];
}
void Program_Project7()
{
	int rows = inputInteger("\nEnter the number of rows: ");
	int columns = inputInteger("\nEnter the number of columns: ");

	int *arrayPtr = create2DArray(rows, columns);
	display(arrayPtr, rows, columns);

	cout << endl << endl;
	int desired_row = inputInteger("\nEnter the desired row: ", 0, rows - 1);
	int desired_column = inputInteger("\nEnter the desired column: ", 0, columns - 1);
	int val;
	cout << "\nEnter the value: ";
	cin >> val;

	set(arrayPtr, rows, columns, desired_row, desired_column, val);

	display(arrayPtr, rows, columns);

	cout << "\n\nThe value of arrayPtr[desired_row][desired_column]: " << get(arrayPtr, rows, columns, desired_row, desired_column) << endl;

	delete[] arrayPtr;

	cin.ignore();
}

void Program_Project8()
{
	int max = inputInteger("\nEnter the maximum value of the grade: ", true);
	vector<int> grades;
	int input;
	do
	{
		input = inputInteger("\nEnter the student's grade: ", -1, max);
		grades.push_back(input);

	} while (input != -1);

	int sizeOfH = max + 1;
	int *histogram = new int[sizeOfH];

	for (int i = 0; i < sizeOfH; i++)
		histogram[i] = 0;

	for (int i = 0; i < grades.size(); i++)
		for (int j = 0; j < sizeOfH; j++)
			if (j == grades[i])
			{
				histogram[j]++;
				break;
			}

	cout << endl;
	for (int i = 0; i < sizeOfH; i++)
		if (histogram[i] > 0)
			if(i>9)
			cout << "Number of "  << i   << "'s: " << setw(9) << right << histogram[i] << endl;
			else
				cout << "Number of " << i << "'s: " << setw(10) << right << histogram[i] << endl;

	delete[] histogram;

	cin.ignore();
}

