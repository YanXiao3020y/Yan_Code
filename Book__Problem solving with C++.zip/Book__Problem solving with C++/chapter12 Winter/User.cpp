#include "User.h"

namespace
{
	bool isValid()
	{
		return(username.length() == 8);
	}
}
namespace Authenticate
{
	void inputUserName()
	{
		do
		{
			cout << "\nEnter your username (8 letters only): ";
			cin >> username;
		} while (!isValid());
	}

	string getUserName()
	{
		return username;
	}
}