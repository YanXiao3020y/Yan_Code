#ifndef PASSWORD_H
#define PASSWORD_H

#include <iostream>
#include <string>
using namespace std;

namespace Authenticate
{
	void inputPassword();

	string getPassword();
}

#endif