#ifndef MONEY_H
#define MONEY_H

#include <iostream>

using namespace std;

class Money
{
private: 
	long allCents;
public:
	Money();

	Money(long dollars);

	Money(long dollars, int cents);

	friend Money operator +(const Money& amount1, const Money& amount2);

	friend Money operator -(const Money& amount1, const Money& amount2);

	friend Money operator -(const Money& amount);

	friend bool operator ==(const Money& amount1, const Money& amount2);

	friend bool operator <=(const Money& amount1, const Money& amount2);

	friend bool operator >=(const Money& amount1, const Money& amount2);

	friend bool operator <(const Money& amount1, const Money& amount2);

	friend bool operator >(const Money& amount1, const Money& amount2);

	double getValue() const;

	friend istream& operator >>(istream& ins, Money& amount);
	//Overloads the >> operator so it can be used to input values of type Money.

	friend ostream& operator <<(ostream& outs, const Money& amount);
	//Overloads the << operator so it can output the values of type Money. Precedes each output value of type Money with a dolloar sign. 
	
	Money percent(int percentFigure) const;
	//Returns a percentage of the money amount in the calling object. e.g. if percentFigure == 10, then returns 10% of amount from the calling object.
};

#endif 