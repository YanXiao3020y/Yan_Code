#ifndef STRINGSET_H
#define STRINGSET_H

#include <iostream>
#include <vector>
#include <string>
using namespace std;

class StringSet
{
private:
	vector <string> v1;
	int size;
public:
	StringSet();

	StringSet(int theSize);

	StringSet(string a[], int theSize);
	//Initializes v1 to a[].

	void add(string aString);
	//Adds a string to the set.

	void remove(string aString);
	//Remove a string from the set.
	
	void clear();
	//Clears the entire set.
	
	int sizeOfString() const;
	//Returns the number of strings in the set.

	friend ostream& operator <<(ostream& outs, const StringSet& theObject);
	//Overloads the << operator so it can output the values of type StringSet.

	friend StringSet operator +(const StringSet& s1, const StringSet& s2);
	//Overloads the + operator so that it returns the union of two StringSEt objects.
	
	friend StringSet operator *(const StringSet& s1, const StringSet& s2);
	//Overloads the * operator so that it returns the intersection of two StringSEt objects.

};

#endif 