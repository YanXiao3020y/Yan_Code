#include "Money.h"

int digitToInt(char c)//Returns the integer for the digit; e.g. digitToInt('3') returns 3.
{
	return(static_cast<int> (c) - static_cast<int> ('0'));
}


Money::Money() : allCents(0)
{}

Money::Money(long dollars) : allCents(dollars * 100)
{}

Money::Money(long dollars, int cents) : allCents(dollars * 100 + cents)
{}

Money operator +(const Money& amount1, const Money& amount2)
{
	Money temp;
	temp.allCents = amount1.allCents + amount2.allCents;
	return temp;
}

Money operator -(const Money& amount1, const Money& amount2)
{
	Money temp;
	temp.allCents = amount1.allCents - amount2.allCents;
	return temp;
}

Money operator -(const Money& amount)
{
	Money temp;
	temp.allCents = -amount.allCents;
	return temp;
}

bool operator ==(const Money& amount1, const Money& amount2)
{
	return (amount1.allCents == amount2.allCents);
}

bool operator <=(const Money& amount1, const Money& amount2)
{
	return (amount1.allCents <= amount2.allCents);
}

bool operator >=(const Money& amount1, const Money& amount2)
{
	return (amount1.allCents >= amount2.allCents);
}

bool operator <(const Money& amount1, const Money& amount2)
{
	return (amount1.allCents < amount2.allCents);
}

bool operator >(const Money& amount1, const Money& amount2)
{
	return (amount1.allCents > amount2.allCents);
}

double Money::getValue() const
{
	return allCents * 0.01;
}

istream& operator >>(istream& ins, Money& amount)//Overloads the >> operator so it can be used to input values of type Money.
{
	char oneChar, decimalPoint, digit1, digit2;//digits for the amount of cents
	long dollars;
	int cents;
	bool negative = false;

	ins >> oneChar;
	if (oneChar == '-')
	{
		negative = true;
		ins >> oneChar;//reads '$'.
	}

	ins >> dollars >> decimalPoint >> digit1 >> digit2;

	if (oneChar != '$' || decimalPoint != '.' || !isdigit(digit1) || !isdigit(digit2))
	{
		cout << "ERROR-3A: illegal form for money input.\n";
		cin.ignore();
	}

	cents = digitToInt(digit1) * 10 + digitToInt(digit2);

	amount.allCents = dollars * 100 + cents;
	if (negative)
		amount.allCents = -amount.allCents;

	return ins;
}

ostream& operator <<(ostream& outs, const Money& amount)//Overloads the << operator so it can output the values of type Money. Precedes each output value of type Money with a dolloar sign. 
{
	long positiveCents, dollars, cents;
	positiveCents = labs(amount.allCents);
	dollars = positiveCents / 100;
	cents = positiveCents % 100;

	if (amount.allCents < 10)
		outs << "-$" << dollars << '.';
	else
		outs << "$" << dollars << '.';

	if (cents < 10)
		outs << '0';
	outs << cents;

	return outs;
}

Money Money::percent(int percentFigure) const
{
	Money result;
	result.allCents  = percentFigure * 0.01 * allCents;

	return result;
}