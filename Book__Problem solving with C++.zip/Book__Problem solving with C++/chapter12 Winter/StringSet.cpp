#include "StringSet.h"

StringSet::StringSet() : size(0)
{}

StringSet::StringSet(int theSize) : size(theSize)
{}

StringSet::StringSet(string a[], int theSize) : size(theSize)//Initializes v1 to a[].
{
	for (int i = 0; i < theSize; i++)
	{
		string s1 = a[i];
		v1.push_back(s1);
	}
}

void StringSet::add(string aString) //Adds a string to the set.
{
	v1.push_back(aString);
	size++;
}

void StringSet::remove(string aString) //Remove a string from the set.
{
	int index = -1;
	for (int i = 0; i < size; i++)
		if (aString == v1[i])
		{
			index = i;
			break;
		}

	if (index != -1)
	{
		StringSet temp(size - 1);
		for (int i = 0; i < size; i++)
			if (i != index)
			{
				string s1 = v1[i];
				temp.v1.push_back(s1);
			}

		clear();
		size = temp.size;
		for (int i = 0; i < size; i++)
		{
			string s1 = temp.v1[i];
			v1.push_back(s1);
		}
	}
}

void StringSet::clear() //Clears the entire set.
{
	size = 0;
	v1.resize(0);
}

int StringSet::sizeOfString() const //Returns the number of strings in the set.
{
	return size;
}

ostream& operator <<(ostream& outs, const StringSet& theObject)//Overloads the << operator so it can output the values of type StringSet.
{
	for (int i = 0; i < theObject.size; i++)
		outs << theObject.v1[i] << " ";
	return outs;
}

StringSet operator +(const StringSet& s1, const StringSet& s2)//Overloads the + operator so that it returns the union of two StringSEt objects.
{
	StringSet temp(s1.size);
	for (int i = 0; i < s1.size; i++)
	{
		string string1 = s1.v1[i];
		temp.v1.push_back(string1);
	}
	for (int i = 0; i < s2.size; i++)
	{
		bool check = true;
		for (int j = 0; j < s1.size; j++)
			if (s2.v1[i] == s1.v1[j])
			{
				check = false;
				break;
			}
		if (check)
		{
			string string1 = s2.v1[i];
			temp.v1.push_back(string1);
			temp.size++;
		}
	}
	return temp;
}
StringSet operator *(const StringSet& s1, const StringSet& s2)//Overloads the * operator so that it returns the intersection of two StringSEt objects.
{
	StringSet temp;

	for (int i = 0; i < s2.size; i++)
	{
		bool check = false;
		for (int j = 0; j < s1.size; j++)
			if (s2.v1[i] == s1.v1[j])
			{
				check = true;
				break;
			}
		if (check)
		{
			string string1 = s2.v1[i];
			temp.v1.push_back(string1);
			temp.size++;
		}
	}

	return temp;
}