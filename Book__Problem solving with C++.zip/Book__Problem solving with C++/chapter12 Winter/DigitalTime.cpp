#include "DigitalTime.h"

namespace
{
	int digitToInt(char c) //Returns the integer for the digit. e.g. digitToInt('3') returns 3.
	{
		return(static_cast<int>(c) - static_cast<int>('0'));
	}

	void readHour(istream& ins, int& theHour)//theHours has been set to the hour part of the time. The colon has been discarded and the next input to be read is the minute.
	{
		char c1, c2;
		ins >> c1 >> c2;
		if (!(isdigit(c1) && (isdigit(c2) || c2 == ':')))
		{
			cout << "ERROR-1A: illegal input to readHour, which the format is wrong.\n";
			cin.ignore();
		}
		if (isdigit(c1) && c2 == ':')
			theHour = digitToInt(c1);
		else
		{
			theHour = (digitToInt(c1) * 10) + digitToInt(c2);
			ins >> c2;//discards ':'
			if (c2 != ':')
			{
				cout << "ERROR-1B: illegal input to readHour, which the format should include ':'.\n";
				cin.ignore();
			}
		}
		if (theHour < 0 || theHour > 23)
		{
			cout << "ERROR-1C: illegal input to readHour, which theHour should be within 0 and 23.\n";
			cin.ignore();
		}
	}

	void readMinute(istream& ins, int& theMinute)//reads the minute from the stream ins after readHour has read the hour.
	{
		char c1, c2;
		ins >> c1 >> c2;
		if (!(isdigit(c1) && isdigit(c2)))
		{
			cout << "ERROR-1D: illegal input to readMinute, which the format is wrong.\n";
			cin.ignore();
		}

		theMinute = digitToInt(c1) * 10 + digitToInt(c2);

		if (theMinute < 0 || theMinute>59)
		{
			cout << "ERROR-1E: illegal input to readMinute, which theMinute should be within 0 to 59.\n";
			cin.ignore();
		}
	}

}

namespace Digital_Time
{

	DigitalTime::DigitalTime() : hour(0), minute(0), minutes(0) //Initializes the time value to 0:00 (which is midnight).
	{}

	DigitalTime::DigitalTime(int theHour, int theMinute) : hour(theHour), minute(theMinute) //Initializes the time value to theHour and theMinute.
	{
		minutes = hour * 60 + minute;
	}

	DigitalTime::DigitalTime(int theMinutes)//Initializes the time value to theMinutes.
	{
		minutes = theMinutes;
		hour = theMinutes / 60;
		minute = theMinutes % 60;
	}

	bool operator ==(const DigitalTime& time1, const DigitalTime& time2)//Returns true if time1 and time2 represent the same time; otherwise, returns false.
	{
		return (time1.hour == time2.hour && time1.minute == time2.minute);
	}

	void DigitalTime::advance(int minutesAdded) //The time has been changed to minutesAdded minutes later.
	{
		minutes += minutesAdded;

		int grossMinutes = minute + minutesAdded;
		minute = grossMinutes % 60;

		int hourAdjustment = grossMinutes / 60;
		hour = (hour + hourAdjustment) % 24;
	}

	void DigitalTime::advance(int hoursAdded, int minutesAdded) //The time has been changed to minutesAdded minutes later.
	{
		minutes += hoursAdded * 60;
		hour = (hour + hoursAdded) % 24;
		advance(minutesAdded);
	}

	istream& operator >>(istream& ins, DigitalTime& theObject) //Overloads the >> operator for input values of type DigltalTime.
	{
		readHour(ins, theObject.hour);
		readMinute(ins, theObject.minute);
		theObject.minutes = theObject.hour * 60 + theObject.minute;
		return ins;
	}

	ostream& operator <<(ostream& outs, const DigitalTime& theObject) //Overloads the << operator for output values of type DigltalTime.
	{
		outs << theObject.hour << ':';
		if (theObject.minute < 10)
			outs << '0';
		outs << theObject.minute;
		return outs;
	}

	void DigitalTime::intervalSince(const DigitalTime& aPreviousTime, int& hoursInInterval, int& minutesInInterval) const
	{
		int totalMinutesOfC = hour * 60 + minute;
		int totalMinutesOfP = aPreviousTime.hour * 60 + aPreviousTime.minute;

		int diff = totalMinutesOfC - totalMinutesOfP;

		hoursInInterval = diff / 60;
		minutesInInterval = diff % 60;
	}

	int DigitalTime::getTotalMinutes() const
	{
		return minutes;
	}

	void DigitalTime::setTotalMinutes(int theMinutes)
	{
		minutes = theMinutes;
		hour = theMinutes / 60;
		minute = theMinutes % 60;
	}
}