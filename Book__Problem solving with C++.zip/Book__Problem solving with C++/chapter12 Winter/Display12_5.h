#ifndef DISPLAY12_5
#define DISPLAY12_5

#include <iostream>
using namespace std;

namespace yx
{
	void greeting();
}
namespace yxx
{
	void greeting();
}

#endif 