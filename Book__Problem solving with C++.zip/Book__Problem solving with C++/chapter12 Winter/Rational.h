#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>
#include "Input.h"
using namespace std;

namespace Rational_number
{
	class Rational
	{
	private:
		int num[2];//num[0] represents numerator, and num[1] represents denominator.
	public:
		Rational();
		//Initializes num[0] to 0, and initiliazes num[1] to 1.

		Rational(int wholeNumber);
		//Initializes num[0] to wholeNumber, and initiliazes num[1] to 1.

		Rational(int theNumerator, int theDenominator);
		//Initializes num[0] to theNumerator, and initiliazes num[1] to theDenominator if theDenominator does not equal to 0, otherwise, initializes it to 1.

		friend istream& operator >>(istream& ins, Rational& theObject);
		//Overloads the operator >> so it can be used to input the values of type Rational. If denominator equals to 0, then it will be changed to 1.

		friend ostream& operator <<(ostream& outs, Rational& theObject);
		// Overloads the operator << so it can be used to output the values of type Rational.

		friend bool operator ==(const Rational& first, const Rational& second);
		//Overloads the operator ==. Returns true if first euqal to second, otherwise, returns false.

		friend bool operator <(const Rational& first, const Rational& second);
		//Overloads the operator <. Returns true if first is less than second, otherwise, returns false.

		friend bool operator <=(const Rational& first, const Rational& second);
		//Overloads the operator <=. Returns true if first is less than or equals to second, otherwise, returns false.

		friend bool operator >(const Rational& first, const Rational& second);
		//Overloads the operator >. Returns true if first is great than second, otherwise, returns false.

		friend bool operator >=(const Rational& first, const Rational& second);
		//Overloads the operator >=. Returns true if first is great than or equals to second, otherwise, returns false.

		friend Rational operator +(const Rational& first, const Rational& second);
		//Overloads the operator + so it can return the result that first adds second.

		friend Rational operator -(const Rational& first, const Rational& second);
		//Overloads the operator - so it can return the result that first subtracts second.

		friend Rational operator *(const Rational& first, const Rational& second);
		//Overloads the operator * so it can return the result that first multiples second.

		friend Rational operator /(const Rational& first, const Rational& second);
		//Overloads the operator / so it can return the result that first divides second.

		void normalization();
		//The denominator will be positive, and the numberator and denominator are as small sa possible.

	};
}

#endif 