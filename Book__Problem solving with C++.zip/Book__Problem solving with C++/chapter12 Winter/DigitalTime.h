#ifndef DIGITALTIME_H
#define DIGITALTIME_H

#include <iostream>

using namespace std;

namespace Digital_Time
{
	class DigitalTime
	{
	private:
		int hour, minute;
		int minutes;
	public:
		DigitalTime();
		//Initializes the time value to 0:00 (which is midnight).

		DigitalTime(int theHour, int theMinute);
		//Initializes the time value to theHour and theMinute.

		DigitalTime(int theMinutes);
		//Initializes the time value to theMinutes.


		friend bool operator ==(const DigitalTime& time1, const DigitalTime& time2);
		//Returns true if time1 and time2 represent the same time; otherwise, returns false.

		void advance(int minutesAdded);
		//The time has been changed to minutesAdded minutes later.

		void advance(int hoursAdded, int minutesAdded);
		//The time has been changed to minutesAdded minutes later.

		friend istream& operator >>(istream& ins, DigitalTime& theObject);
		//Overloads the >> operator for input values of type DigltalTime.

		friend ostream& operator <<(ostream& ins, const DigitalTime& theObject);
		//Overloads the << operator for output values of type DigltalTime.

		void intervalSince(const DigitalTime& aPreviousTime, int& hoursInInterval, int& minutesInInterval) const;//Computes the time interval between two values of type DigitalTime.

		int getTotalMinutes() const;
		//Gets minutes.

		void setTotalMinutes(int theMinutes);
		//Sets minutes to theMinutes.

	};

}

#endif 