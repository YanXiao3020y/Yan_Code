//Yan Xiao
//12/27/18 (started)
//12/29/18 (finished)
//Winter practice
//Chapter12

#include <iostream>
#include "DigitalTime.h"
#include "Money.h"
#include "Display12_5.h"
#include "User.h"
#include "Password.h"
#include "Rational.h"
#include "StringSet.h"

using namespace std;
using namespace Digital_Time;
using namespace Authenticate;
using namespace Rational_number;


void PracticeProgram1();
//Testing the class of type DigitalTime.

void PracticeProgram2();
//Testing the class of type Digitaltime, which changed the private variable to minutes.

void PracticeProgram3();
//Testing the class of type Money.

void Display12_5();
//From book.

void PracticeProgram5();
//Testing the files of User and Password.

void Program_Project2();
//Testing the class of type Rational.

void Program_Project3();
//Testing the class of type StringSet.

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\tChapter 11" << endl;
		cout << "\t=====================================" << endl;
		cout << " \t\t1: Practice Program 1" << endl;
		cout << " \t\t2: Practice Program 2" << endl;
		cout << " \t\t3: Practice Program 3" << endl;
		cout << " \t\t4: Practice Program 5" << endl;
		cout << " \t\t5: Display12_5" << endl;
		cout << " \t\t6: Programming Project2" << endl;
		cout << "\t\t7: Programming Project3" << endl;
		cout << "\t=====================================" << endl;

		cout << " \toption: ";
		char option[80];
		cin.getline(option, 80, '\n');
		cout << endl;

		switch (atoi(option))
		{
		case 1: PracticeProgram1(); break;
		case 2: PracticeProgram2(); break;
		case 3: PracticeProgram3(); break;
		case 4: PracticeProgram5(); break;
		case 5: Display12_5(); break;
		case 6: Program_Project2(); break;
		case 7: Program_Project3(); break;
		default: exit(0);
		}

		cout << endl;
		system("pause");
		cin.clear();
	}

	return 0;
}

void PracticeProgram1()
{
	DigitalTime clock, oldClock;

	cout << "\nEnter the time in 24-hour notation: ";
	cin >> clock;

	oldClock = clock;
	clock.advance(15);
	if (clock == oldClock)
		cout << "Something is wrong.\n";
	cout << "You entered " << oldClock << ".\n";
	cout << "15 minutes later the time will be " << clock << ".\n";

	clock.advance(2, 15);
	cout << "2 hours and 15 minutes after that, the time will be " << clock << ".\n";

	DigitalTime current(5, 45), previous(2, 30);
	int hours, minutes;
	current.intervalSince(previous, hours, minutes);
	cout << "\nThe time interval between " << previous << " and " << current << " is " << hours << " hours and " << minutes << " minutes.\n";

	cin.ignore();
}

void PracticeProgram2()
{
	DigitalTime current(345), previous(150);
	int hours, minutes;
	current.intervalSince(previous, hours, minutes);
	cout << "The time interval between " << previous << " and " << current << " is " << hours << " hours and " << minutes << " minutes.\n";
	current.setTotalMinutes(300);
	cout << "The total minutes of the current time is " << current.getTotalMinutes() << ".\n";

	cin.ignore();
}

void PracticeProgram3()
{
	Money test1, test2(100), test3(100, 100);

	cout << "\nEnter the amount of money (e.g. -$70.00): ";
	cin >> test1;

	test2 = -test2;
	cout << test2 << endl;

	test2 = test1 + test3;
	cout << test2 << endl;

	test2 = test3 - test1;
	cout << test2 << endl;
	cout << test2.getValue() << endl;

	cout << "test2 == test1 : " << (test2 == test1 ? "Yes.\n" : "No.\n");
	cout << "test2 <= test1 : " << (test2 <= test1 ? "Yes.\n" : "No.\n");
	cout << "test2 >= test1 : " << (test2 >= test1 ? "Yes.\n" : "No.\n");
	cout << "test2 > test1 : " << (test2 > test1 ? "Yes.\n" : "No.\n");
	cout << "test2 < test1 : " << (test2 < test1 ? "Yes.\n" : "No.\n");

	Money result = test3.percent(10);
	cout << "test3.percent(10): " << result << endl;

	cin.ignore();
}

void bigGreeting()
{
	cout << "Hello from here!\n";
}
void Display12_5()
{
	yx::greeting();
	yxx::greeting();

	bigGreeting();

	cin.ignore();
}

void PracticeProgram5()
{
	inputUserName();
	inputPassword();
	cout << "Your username is " << getUserName() << " and your password is : " << getPassword() << endl;

	cin.ignore();
}

void Program_Project2()
{
	Rational test1, test2(2);
	cout << "\nThe first rational number: ";
	cin >> test1;
	cout << "\nThe second rational number: ";
	cin >> test2;

	cout << "\nFirst: " << test1 << endl;
	cout << "Second: " << test2 << endl << endl;

	Rational result(1, 0);

	//Addition
	result = test1 + test2;
	cout << test1 << " + " << test2 << " = " << result << endl;

	//Subtraction
	result = test1 - test2;
	cout << test1 << " - " << test2 << " = " << result << endl;

	//Multiplication
	result = test1 * test2;
	cout << test1 << " * " << test2 << " = " << result << endl;

	//Division
	result = test1 / test2;
	cout << test1 << " / " << test2 << " = " << result << endl << endl;

	cout << "First == Second: " << (test1 == test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First < Second: " << (test1 < test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First > Second: " << (test1 > test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First <= Second: " << (test1 <= test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First >= Second: " << (test1 >= test2 ? "Yes.\n" : "No.\n") << endl;

	cin.ignore();
}

void Program_Project3()
{
	const int SIZE_OF_ARRAY = 5;
	string a[SIZE_OF_ARRAY];

	for (int i = 0; i < SIZE_OF_ARRAY; i++)
		a[i] = i + 'a';
	for (int i = 0; i < SIZE_OF_ARRAY; i++)
		cout << a[i] << " ";
	cout << endl;
	StringSet test1, test2(a, SIZE_OF_ARRAY);

	test1.add("Hey!");
	test1.add("Hello !");
	test1.add("Here!");
	test1.add("Heyee!");
	test1.add("Heyll!");

	cout << "test1: " << test1 << endl;
	cout << "test2: " << test2 << endl;

	test2.remove("HH!");
	cout << "test2: " << test2 << endl;

	test2.remove("a");
	test2.remove("b");
	cout << "test2: " << test2 
		<< "\ntest2.sizeOfString(): " << test2.sizeOfString() << endl;

	test2.add("Here!");
	test2.add("Heyee!");
	cout << "test2: " << test2 << endl;

	StringSet unionOf;
	unionOf = test1 + test2;
	cout << "unionOf: " << unionOf << endl;

	StringSet intersectionOf;
	intersectionOf = test1 * test2;
	cout << "intersectionOf: " << intersectionOf << endl;

	cin.ignore();
}
