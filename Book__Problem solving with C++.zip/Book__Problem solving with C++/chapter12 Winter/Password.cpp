#include "Password.h"

namespace
{
	string password;
	bool isValid()
	{
		bool check = false;
		for (int i = 0; i < password.length(); i++)
			if (!isalpha(password[i]))
				check = true;
		return (check && password.length() >= 8);
	}
}
namespace Authenticate
{
	void inputPassword()
	{
		do
		{
			cout << "\nEnter your password (at least 8 characters and at least one nonletter): ";
			cin >> password;
		} while (!isValid());
	}

	string getPassword()
	{
		return password;
	}
}