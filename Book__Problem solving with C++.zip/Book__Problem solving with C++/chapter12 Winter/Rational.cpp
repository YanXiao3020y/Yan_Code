#include "Rational.h"

namespace Rational_number
{
	Rational::Rational() //Initializes num[0] to 0, and initiliazes num[1] to 1.
	{
		num[0] = 0;
		num[1] = 1;
	}

	Rational::Rational(int wholeNumber)//Initializes num[0] to wholeNumber, and initiliazes num[1] to 1.
	{
		num[0] = wholeNumber;
		num[1] = 1;
	}

	Rational::Rational(int theNumerator, int theDenominator)//Initializes num[0] to theNumerator, and initiliazes num[1] to theDenominator if theDenominator does not equal to 0, otherwise, initializes it to 1.
	{
		num[0] = theNumerator;
		if (theDenominator == 0)
			num[1] = 1;
		else
			num[1] = theDenominator;
	}

	istream& operator >>(istream& ins, Rational& theObject)//Overloads the operator >> so it can be used to input the values of type Rational. If denominator equals to 0, then it will be changed to 1.
	{
		cout << "\nEnter the rational number (e.g. 1/2): ";
		ins >> theObject.num[0];
		char ch;
		cin.get(ch);
		ins >> theObject.num[1];
		if (theObject.num[1] == 0)
			theObject.num[1] = 1;
		return ins;
	}

	ostream& operator <<(ostream& outs, Rational& theObject)//Overloads the operator << so it can be used to output the values of type Rational.
	{
		theObject.normalization();
		outs << theObject.num[0] << "/" << theObject.num[1];
		return outs;
	}

	bool operator ==(const Rational& first, const Rational& second)//Overloads the operator ==. Returns true if first euqal to second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] == second.num[0] * first.num[1]);
	}

	bool operator <(const Rational& first, const Rational& second)//Overloads the operator <. Returns true if first is less than second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] < second.num[0] * first.num[1]);
	}

	bool operator <=(const Rational& first, const Rational& second)//Overloads the operator <=. Returns true if first is less than or equals to second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] <= second.num[0] * first.num[1]);
	}

	bool operator >(const Rational& first, const Rational& second)//Overloads the operator >. Returns true if first is great than second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] > second.num[0] * first.num[1]);
	}

	bool operator >=(const Rational& first, const Rational& second)//Overloads the operator >=. Returns true if first is great than or equals to second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] >= second.num[0] * first.num[1]);
	}

	Rational operator +(const Rational& first, const Rational& second)//Overloads the operator + so it can return the result that first adds second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[1] + second.num[0] * first.num[1];
		temp.num[1] = first.num[1] * second.num[1];
		return temp;
	}

	Rational operator -(const Rational& first, const Rational& second)//Overloads the operator - so it can return the result that first subtracts second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[1] - second.num[0] * first.num[1];
		temp.num[1] = first.num[1] * second.num[1];
		return temp;
	}

	Rational operator *(const Rational& first, const Rational& second)//Overloads the operator * so it can return the result that first multiples second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[0];
		temp.num[1] = first.num[1] * second.num[1];
		return temp;
	}

	Rational operator /(const Rational& first, const Rational& second)//Overloads the operator / so it can return the result that first divides second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[1];
		temp.num[1] = first.num[1] * second.num[0];
		return temp;
	}

	void Rational::normalization()//The denominator will be positive, and the numberator and denominator are as small sa possible.
	{
		if (num[1] < 0)
		{
			num[1] = -num[1];
			num[0] = -num[0];
		}
		for (int i = 2; i < 100; i++)
			if (num[0] % i == 0 && num[1] % i == 0)
			{
				num[0] /= i;
				num[1] /= i;
				i--;
			}
	}
}