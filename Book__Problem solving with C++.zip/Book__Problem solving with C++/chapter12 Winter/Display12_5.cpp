#include "Display12_5.h"

namespace yx
{
	void greeting()
	{
		cout << "Hello from yx!\n";
	}
}
namespace yxx
{
	void greeting()
	{
		cout << "Hello from yxx!\n";
	}
}