#ifndef LIST_H
#define LIST_H

#include <iostream>
using namespace std;

const int MAX_SIZE = 50;

namespace LinkedList
{
	struct Node
	{
		double item;//Stores the value of the item on the linked list.
		Node *link;
	};

	typedef Node *NodePtr;

	class List
	{
	private:
		NodePtr head;
		NodePtr current;
		int size;//Number of the linked list's positions filled
	public:
		~List();//Destructor.

		List();
		//Initializes to empty list.

		void addItem(double newItem);
		//The newItem is added to the linked list.
	
		bool full() const;
		//Returns true if the linked list is full; otherwise, returns false.

		friend ostream& operator << (ostream& outs, const List& theObject);
		//Overloads the << operator so it can be used to output values of type List.

		int getSize() const;
		//Returns the number  of items on the linked list.

		double getItem(int index);
		//Returns a value of type double, which is the item in that position on the linked list.

		double back() const;
		//Returns the last item on the linked list.

		double front() const;
		//Returns the first item on the linked list.

		double getCurrent() const;
		//Returns the current item on the linked list.

		void deleteLast();
		//Deletes the last element on the linked list.
		
		void advance();
		//Advances the item that current() returns.

		void reset();
		//Make current() return the first item on the linked list.
		
		void insert(double afterMe, double insertMe);
		//Inserts insertMe into the list after afterMe and increments size by one.

		friend istream& operator >> (istream& ins, List& theObject); 
		//Overloads the >> operator so it can be used to input the values of type List.

	};


}

#endif 