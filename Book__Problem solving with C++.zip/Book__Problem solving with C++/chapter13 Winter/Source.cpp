//Yan Xiao
//12/29/18 (started)
//12/31/18 (finished)
//Winter practice
//Chapter 13

#include <iostream>
#include <ctime>
#include <iomanip>
#include "List.h"
#include "Input.h"
#include "Queue.h"
#include "Stack.h"

using namespace std;
using namespace Validation;

void ProgrammingProject1();
//Testing the function reverse.

void ProgrammingProject2();
//Testing the function mergeLists.

void ProgrammingProject4();
//Testing the class of List.

void ProgrammingProject5();
//Testing the class of List, which has more member functions than ProgrammingProject4.

void ProgrammingProject8();
//This program implements the queue and simulates coustomers entering and leving the queue.

void ProgrammingProject10();
//This program simulates a RPN calculator (Reverse Polish Notation).

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\t\tChapter 13\n";
		cout << "\t\t=======================================\n";
		cout << "\t\t\t1: Programming Project1\n";
		cout << "\t\t\t2: Programming Project2\n";
		cout << "\t\t\t3: Programming Project4\n";
		cout << "\t\t\t4: Programming Project5\n";
		cout << "\t\t\t5: Programming Project8\n";
		cout << "\t\t\t6: Programming Project10\n";
		cout << "\t\t=======================================\n";
		cout << "\t\t option: ";
		char option[80];
		cin.getline(option, 80, '\n');
		cout << endl;
		switch (atoi(option))
		{
		case 1: ProgrammingProject1(); break;
		case 2: ProgrammingProject2(); break;
		case 3: ProgrammingProject4(); break;
		case 4: ProgrammingProject5(); break;
		case 5: ProgrammingProject8(); break;
		case 6: ProgrammingProject10(); break;
		default: return 0;
		}
		system("pause");
	}
	return 0;
}

namespace projectOneANdTwo
{
	struct Node
	{
		int data;
		Node *link;
	};

	typedef Node* NodePtr;

	void headInsert(NodePtr& head, int theNumber)
	{
		NodePtr tempPtr = new Node;
		tempPtr->data = theNumber;
		tempPtr->link = head;
		head = tempPtr;
	}
	
	void toDelete(NodePtr& head)
	{
		while (head != NULL)
		{
			NodePtr toBeDelete = head;
			head = head->link;
			delete toBeDelete;
		}
	}
	void reverse(NodePtr& head)//Reverses the order of its nodes.//The first version
	{
		NodePtr tempPtr, top = NULL;

		for (NodePtr iter = head; iter != NULL; iter = iter->link)
		{
			tempPtr = new Node;
			tempPtr->data = iter->data;
			tempPtr->link = top;
			top = tempPtr;
		}
		toDelete(head);
		head = top;
	}
	//void reverse(NodePtr& head)//Reverses the order of its nodes.//The second version
	//{
	//	NodePtr current = head, previous = NULL, next = NULL;
	//	while (current != NULL)
	//	{
	//		next = current->link;
	//		current->link = previous;
	//		previous = current;
	//		current = next;
	//	}
	//	head = previous;
	//}
	void output(const NodePtr head)//Outputs the values.
	{
		for (NodePtr iter = head; iter != NULL; iter = iter->link)
			cout << iter->data << " ";
		cout << endl;
	}
	NodePtr mergeLists(NodePtr& head1, NodePtr& head2)
		//Precondition: they all sorted from smallest to largest values.
		//Returns a pointer to the head of the new linked list that contains all of the nodes in the original two lists and is sorted from smallest to largest values. And the two pointer variable arguments should have the value of NULL when the function call ends.
	{
		NodePtr newList = NULL;
		for (NodePtr iter = head1; iter != NULL; iter = iter->link)//Copies from head1.
		{
			NodePtr tempPtr = new Node;
			tempPtr->data = iter->data;
			tempPtr->link = newList;
			newList = tempPtr;
			tempPtr = tempPtr->link;
		}
		reverse(newList);

		int count = 0;
		NodePtr tempList = newList;
		NodePtr nextOfHead2 = NULL;
		if (newList != NULL)//Whether head1 is empty or not
			for (NodePtr iter = head2; iter != NULL; iter = iter->link)//If newList->data is greater than the datas in head2, then insert them before newList->data.
			{
				if (iter->data <= tempList->data && count == 0)
				{
					headInsert(newList, iter->data);
					count++;
				}
				else if (iter->data < tempList->data && count != 0)
				{
					NodePtr tempPtr = new Node;
					tempPtr->data = iter->data;
					tempPtr->link = newList->link;
					newList->link = tempPtr;
				}
				else
				{
					nextOfHead2 = iter;
					break;
				}
			}
		else
		{
			for (NodePtr iter = head2; iter != NULL; iter = iter->link)
				headInsert(newList, iter->data);
			reverse(newList);
		}
			
		NodePtr restPtr = NULL;
		NodePtr nextPtr = NULL;
		for (NodePtr iter2 = nextOfHead2; iter2 != NULL; iter2 = iter2->link)//When newList->data is less than the datas in head2, then insert them after the corresponding data in the newList.
		{
			for (NodePtr iter1 = newList; iter1->link != NULL; iter1 = iter1->link)
				if (iter2->data <= iter1->link->data && iter2->data >= iter1->data)
				{
					NodePtr tempPtr = new Node;
					tempPtr->data = iter2->data;
					tempPtr->link = iter1->link;
					iter1->link = tempPtr;
					break;
				}
				else if (iter1->link->link  == NULL)
				{
					if (iter2->data > iter1->data)
					{
						restPtr = iter2;
						nextPtr = iter1;
						break;
					}
				}
			if (restPtr != NULL)
				break;
		}
		if (restPtr != NULL)//The data in head2 is greater than the last data in the newList. So they are inserted after the last data in the newList by order.
		{
			for (NodePtr iter = restPtr; iter != NULL; iter = iter->link)
			{
				nextPtr = nextPtr->link;
				NodePtr tempPtr = new Node;
				tempPtr->data = iter->data;
				tempPtr->link = nextPtr->link;
				nextPtr->link = tempPtr;
			}
		}

		toDelete(head1);
		toDelete(head2);

		return newList;
	}
}
void ProgrammingProject1()
{
	using namespace projectOneANdTwo;
	
	NodePtr head = NULL;
	int size = 5;
	for (int i = 0; i < size; i++)
	{
		headInsert(head, i);
	}
	cout << "Original order: ";
	output(head);

	reverse(head);
	cout << "Reverse order: ";
	output(head);

	cin.ignore();
}

void ProgrammingProject2()
{
	using namespace projectOneANdTwo;

	NodePtr head1 = NULL;
	NodePtr head2 = NULL;
	int size1 = 2;
	int size2 = 2;
	for (int i = 0; i < size1; i++)
	{
		headInsert(head1, i);
	}
	for (int i = -2; i < size2; i++)
	{
		headInsert(head2, i);
	}
	reverse(head1);
	reverse(head2);
	cout << "Head1: ";
	output(head1);
	cout << "Head2: ";
	output(head2);

	NodePtr newList = mergeLists(head1, head2);
	cout << "newList: ";
	output(newList);

	cin.ignore();
}

void ProgrammingProject4()
{
	using namespace LinkedList;

	List test;
	int size = 5;
	for (double i = 0.1; i < size; i++)
		test.addItem(i);
	cout << "test: " << test
		<< "size: " << test.getSize() << endl
		<< "test.getItem (3): " << test.getItem(3) << endl;
	cout << "Is test full: " << (test.full() ? "Yes.\n" : "No.\n");

	cout << "test.back(): " << test.back() << endl;
	test.deleteLast();
	cout << "test: " << test;
	cout << "test.back(): " << test.back() << endl;

	cin.ignore();
}

void ProgrammingProject5()
{
	using namespace LinkedList;

	List test;
	int size = 5;
	for (double i = 0.1; i < size; i++)
		test.addItem(i);
	cout << "test: " << test;

	double afterMe = 1.1;
	double insertMe = 1.22;
	test.insert(afterMe, insertMe);
	cout << "test: " << test;

	cin >> test;
	cout << "test: " << test;

	cout << "test.front(): " << test.front() << endl
		<< "test.back(): " << test.back() << endl;

	test.reset();
	int count = 3;
	for (int i = 0; i < count; i++)
		test.advance();
	cout << "test.getCurrent(): " << test.getCurrent() << endl;

	test.reset();
	cout << "test.getCurrent(): " << test.getCurrent() << endl;


	cout << endl;
	cin.ignore();
}

void ProgrammingProject8()
{
	using namespace Queue_8;


	Queue customer;
	if (customer.empty())
		cout << "\nThe line is empty.\n";
	char choice;
	int count = 0;
	const int num = 3;//The last three customers
	long arrayOfDiff[3];//The length of time which the last three customers spent waiting.
	for (int i = 0; i < num; i++)//Initilizes to 0.
		arrayOfDiff[i] = 0;
	do
	{
		//input
		bool getOutLoop = true;
		do
		{
			choice = inputCharacterOfDigit("\nEnter '1' to simulate a customer's arrival, '2' to help the next customer, or '3' to quit.\n");
			if (choice == '1' || choice == '2' || choice == '3')
				getOutLoop = false;
			else
				cout << "\nERROR-8A: Invalid input, which should be '1', '2' or '3'.\n";

		} while (getOutLoop);
		
		//process
		if (choice == '1')
		{
			long seconds = static_cast<long>(time(NULL));
			customer.add(seconds, ++count);//Saves into Queue.
			cout << "\nCustomer " << customer.getBack()->ticket << " entered the queue at time " << seconds << ".\n";
		}
		else if (choice == '2')
		{
			if (customer.empty())
			{
				cout << "\nThe line is empty.\n";
				continue;
			}
			long seconds = static_cast<long>(time(NULL));
			int tickeNumber = customer.getFront()->ticket;
			long diff = seconds - customer.remove();//The waiting time.
			cout << "\nCustomer " << tickeNumber << " is being helped at time " << seconds << ". Wait time = " << diff << " seconds.\n";
			int index = (tickeNumber + 2) % 3;
			arrayOfDiff[index] = diff;
			double average = 0.0;
			if(tickeNumber == 1)
				average = (arrayOfDiff[0] + arrayOfDiff[1] + arrayOfDiff[2]) / 1.0;
			else if(tickeNumber == 2)
				average = (arrayOfDiff[0] + arrayOfDiff[1] + arrayOfDiff[2]) / 2.0;
			else
				average = (arrayOfDiff[0] + arrayOfDiff[1] + arrayOfDiff[2]) / 3.0;

			cout << fixed << setprecision(0) << "\nThe estimated wait time for customer " << tickeNumber << " is " << average << " seconds.\n\n\n";
		}

		if (customer.empty())
			cout << "\nThe line is empty.\n";

	} while (choice != '3');


	cout << endl;
	cin.ignore();
}

void ProgrammingProject10()
{
	using namespace Stack_10;

	Stack output;
	string input;
	cout << "\nEnter the values (Enter 'q' to quit): \n"
		<< "Enter     : ";
	do
	{
		//for input
		bool getOutLoop = true;
		do
		{
			cin >> input;

			bool noDigit = false;
			for (int i = 0; i < input.length(); i++)
			{
				if (input[i] == '-')
					continue;
				if (!isdigit(input[i]))
				{
					noDigit = true;
					break;
				}
			}


			bool operator_or_q = false;
			if (noDigit)
				if (input == "+" || input == "-" || input == "*" || input == "/" || input == "q")
					operator_or_q = true;
				else
					cout << "\nERROR-10A: Invalid input, which should be either an integer type or an operand or a 'q'.\n";

			if (operator_or_q || !noDigit)
				getOutLoop = false;

		} while (getOutLoop);

		//checks whether output has two integer to be operate or not.
		
		if (!output.empty())
		{
			int value = output.pop();
			if (output.empty() && (input == "+" || input == "-" || input == "*" || input == "/"))
			{
				cout << "ERROR-10B: Invalid input, you should input an integer this time.\n";
				output.push(value);
				continue;
			}
			else
				output.push(value);
		}

		if (input == "+")
		{
			int value1 = output.pop();
			int value2 = output.pop();
			int result = value1 + value2;
			output.push(result);
		}
		else if (input == "-")
		{
			int value1 = output.pop();
			int value2 = output.pop();
			int result = value2 - value1;
			output.push(result);
		}
		else if (input == "*")
		{
			int value1 = output.pop();
			int value2 = output.pop();
			int result = value1 * value2;
			output.push(result);
		}
		else if (input == "/")
		{
			int value1 = output.pop();
			int value2 = output.pop();
			int result = value2 / value1;
			output.push(result);
		}
		else if(input != "q")
		{
			int digit = stoi(input);
			output.push(digit);
		}

		if (input != "q")
			cout << "Enter more: ";

	} while (input != "q");

	cout << "\nThe top of the stack is " << output.pop() << ".\n\n";

	cin.ignore();
}

