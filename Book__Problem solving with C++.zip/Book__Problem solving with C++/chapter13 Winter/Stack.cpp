#include "Stack.h"

namespace Stack_10
{
	Stack::~Stack()//Destructor. Destroys the stack and returns all the memory to the freestore.
	{
		int theData;
		while (!empty())
			theData = pop();
	}

	Stack::Stack() : top(NULL)
	{}

	Stack::Stack(const Stack& aStack)//Copy constructor
	{
		if (aStack.empty())
			top = NULL;
		else
		{
			//first node
			top = new Node;
			top->data = aStack.top->data;
			top->link = NULL;
			NodePtr end = top;

			for (NodePtr iter = aStack.top->link; iter != NULL; iter = iter->link)
			{
				NodePtr tempPtr = new Node;
				tempPtr->data = iter->data;
				tempPtr->link = end->link;
				end->link = tempPtr;
				end = tempPtr;
			}
		}
	}

	void Stack::push(int theData)//TheData has been added to the stack.
	{
		NodePtr tempPtr = new Node;
		tempPtr->data = theData;
		tempPtr->link = top;
		top = tempPtr;
	}

	int Stack::pop()//Returns the top data on the stack and removes that top data from the stack.
	{
		int theData = top->data;
		NodePtr toBeDelete = top;
		top = top->link;
		delete toBeDelete;

		return theData;
	}

	bool Stack::empty()const//Returns true if the stack is empty; otherwise, returns false.
	{
		return (top == NULL);
	}
}