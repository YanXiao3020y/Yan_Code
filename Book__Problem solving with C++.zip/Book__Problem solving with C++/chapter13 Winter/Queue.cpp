#include "Queue.h"

namespace Queue_8
{
	Queue::~Queue()
	{
		while (!empty())
			long removeSecond = remove();
	}

	Queue::Queue() :front(NULL), back(NULL)
	{}

	Queue::Queue(const Queue& aQueue)
	{
		if (aQueue.empty())
			front = back = NULL;
		else
		{
			//First node
			front = new Node;
			front->second = aQueue.front->second;
			front->ticket = aQueue.front->ticket;
			front->link = NULL;
			back = front;

			for (NodePtr iter = aQueue.front->link; iter != NULL; iter = iter->link)
			{
				NodePtr tempPtr = new Node;
				tempPtr->second = iter->second;
				tempPtr->ticket = iter->ticket;
				tempPtr->link = back->link;
				back->link = tempPtr;
				back = tempPtr;
			}
		}
	}

	void Queue::add(long item, int theTicket)//Item has been added to the back of the queue.
	{
		if (empty())
		{
			front = new Node;
			front->second = item;
			front->ticket = theTicket;
			front->link = NULL;
			back = front;
		}
		else
		{
			NodePtr tempPtr = new Node;
			tempPtr->second = item;
			tempPtr->ticket = theTicket;
			tempPtr->link = back->link;
			back->link = tempPtr;
			back = tempPtr;
		}
	}

	long Queue::remove()//Returns the item at the front of the queue and removes that item from the queue.
	{
		long theSecond = front->second;
		NodePtr toBeDelete = front;
		front = front->link;
		delete toBeDelete;

		if (front == NULL)
			back = NULL;

		return theSecond;
	}

	bool Queue::empty() const///Returns true if the queue is empty; otherwise, returns false.
	{
		return (front == NULL);
	}

	NodePtr Queue::getFront() const
	{
		return front;
	}

	NodePtr Queue::getBack() const
	{
		return back;
	}

}