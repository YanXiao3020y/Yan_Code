#ifndef STACK_H
#define STACK_H

#include <iostream>
using namespace std;

namespace Stack_10
{
	struct Node
	{
		int data;
		Node *link;
	};

	typedef Node* NodePtr;

	class Stack
	{
	private:
		NodePtr top;
	public:
		~Stack();
		//Destructor. Destroys the stack and returns all the memory to the freestore.

		Stack();

		Stack(const Stack& aStack);
		//Copy constructor

		void push(int theData);
		//TheData has been added to the stack.

		int pop();
		//Returns the top data on the stack and removes that top data from the stack.

		bool empty()const;
		//Returns true if the stack is empty; otherwise, returns false.

	};

}
#endif