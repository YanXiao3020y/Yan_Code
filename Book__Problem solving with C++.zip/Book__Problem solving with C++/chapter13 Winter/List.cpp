#include "List.h"
#include "Input.h"

using namespace Validation;

namespace LinkedList
{
	List::~List()
	{
		while (head != NULL)
		{
			NodePtr tempPtr = head;
			head = head->link;
			delete tempPtr;
		}
	}

	List::List() : size(0), head(NULL)//Initializes to empty list.
	{}

	void List::addItem(double newItem)//The newItem is added to the linked list.
	{
		NodePtr tempPtr = new Node;
		tempPtr->item = newItem;
		tempPtr->link = head;
		head = tempPtr;
		size++;
	}

	bool List::full() const//Returns true if the linked list is full; otherwise, returns false.
	{
		return(size == MAX_SIZE);
	}

	ostream& operator << (ostream& outs, const List& theObject)//Overloads the << operator so it can be used to output values of type List.
	{
		for (NodePtr iter = theObject.head; iter != NULL; iter = iter->link)
			outs << iter->item << " ";
		outs << endl;
		return outs;
	}

	int List::getSize() const //Returns the number on the linked list.
	{
		return size;
	}

	double List::getItem(int index)//Returns a value of type double, which is the item in that position on the linked list.
	{
		int count = 0;
		NodePtr tempPtr = head;
		while (count++ != index)
			tempPtr = tempPtr->link;

		return tempPtr->item;
	}

	double List::back() const //Returns the last item on the linked list.
	{
		NodePtr tempPtr = head;
		while (tempPtr->link != NULL)
			tempPtr = tempPtr->link;
		return tempPtr->item;
	}

	double List::front() const //Returns the first item on the linked list.
	{
		return head->item;
	}

	double List::getCurrent() const //Returns the current item on the linked list.
	{
		return current->item;
	}

	void List::deleteLast() //Deletes the last element on the linked list.
	{
		if (head != NULL)
		{
			size--;
			NodePtr tempPtr = head;
			while (tempPtr->link->link != NULL)
				tempPtr = tempPtr->link;
			NodePtr toBeDeleted = tempPtr->link;
			tempPtr->link = NULL;

			delete toBeDeleted;
		}
	}

	void List::advance()//Advances the item that current() returns.
	{
		current = current->link;
	}

	void List::reset()//Make current() return the first item on the linked list.
	{
		current = head;
	}

	void List::insert(double afterMe, double insertMe)//Inserts insertMe into the list after afterMe and increments size by one.
	{
		for (NodePtr iter = head; iter != NULL; iter = iter->link)
			if (iter->item == afterMe)
			{
				NodePtr tempPtr = new Node;
				tempPtr->item = insertMe;
				tempPtr->link = iter->link;
				iter->link = tempPtr;
			}
	}

	void headInsert(NodePtr& head, double theNumber)
	{
		NodePtr tempPtr = new Node;
		tempPtr->item = theNumber;
		tempPtr->link = head;
		head = tempPtr;
	}

	istream& operator >> (istream& ins, List& theObject) //Overloads the >> operator so it can be used to input the values of type List.
	{
		double newItem = inputDouble(ins, "\nEnter a number of double: ");
		headInsert(theObject.head, newItem);

		return ins;
	}

}