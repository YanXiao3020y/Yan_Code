#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
using namespace std;

namespace Queue_8
{
	struct Node
	{
		long second;
		int ticket;//the ticket number.
		Node *link;
	};

	typedef Node* NodePtr;

	class Queue
	{
	private:
		NodePtr front;
		NodePtr back;
	public:
		~Queue();

		Queue();

		Queue(const Queue& aQueue);

		void add(long item, int theTicket);
		//Item has been added to the back of the queue.

		long remove();
		//Returns the item at the front of the queue and removes that item from the queue.

		bool empty() const;
		///Returns true if the queue is empty; otherwise, returns false.
		
		NodePtr getFront() const;

		NodePtr getBack() const;

	};

}
#endif 