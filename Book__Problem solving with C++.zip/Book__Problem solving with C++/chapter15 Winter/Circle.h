#ifndef CIRCLE_H
#define CIRCLE_H

#include "Shape.h"

class Circle : public Shape
{
private:
	int radius;
public:
	Circle() : Shape("Circle"), radius(0)
	{}

	Circle(int theRadius) : Shape("Circle"), radius(theRadius)
	{}

	void setRadius(int newRadius)
	{
		this->radius = newRadius;
	}

	double getRadius() const
	{
		return radius;
	}

	virtual double getArea()
	{
		return 3.14159 * radius *radius;
	}

};

#endif 