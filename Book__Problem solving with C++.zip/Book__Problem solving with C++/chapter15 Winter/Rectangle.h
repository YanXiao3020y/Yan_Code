#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Shape.h"

namespace Shape_3
{
	class Rectangle : public Shape
	{
	private:
		int width;
		int height;
	public:
		Rectangle() : Shape("Retangle"), width(0), height(0)
		{}

		Rectangle(int theWidth, int theHeight) : Shape("Retangle"), width(theWidth), height(theHeight)
		{}

		void setWidth(int newWidth)
		{
			width = newWidth;
		}

		int getWidth() const
		{
			return width;
		}

		void setHeight(int newHeight)
		{
			height = newHeight;
		}

		int getHeight() const
		{
			return height;
		}

		virtual double getArea()
		{
			cout.setf(ios::fixed);
			cout.setf(ios::showpoint);
			cout.precision(1);
			return height * width;
		}
	};
}
#endif 