//Yan Xiao
//12/31/18 (started)
//01/01/19 (finished)
//Winter practice
//Chapter 15 Inheritance

#include <iostream>
#include "Administrator.h"
#include "Circle.h"
#include "Rectangle.h"
#include "Doctor.h"
#include "Truck.h"
#include "Rectangle_Figure.h"
#include "Triangle.h"
using namespace std;

void PracticeProgram1();
//Testing the class Administrator, which is derived from the class SalariedEmployee.

void PracticeProgram3();
//Testing the class Circle and Rectangle.

void ProgrammingProject1();
//Testing the class Doctor.

void ProgrammingProject2();
//Testing the class Truck, which contains the class Vehicle and Person.

void ProgrammingProject5();
//Testing the class Triangle and Rectangle, which is derived from Figure.

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\t\tChapter 15\n";
		cout << "\t\t========================================\n";
		cout << "\t\t\t 1: Practice Program1\n";
		cout << "\t\t\t 2: Practice Program3\n";
		cout << "\t\t\t 3: Programming Project1\n";
		cout << "\t\t\t 4: Programming Project2\n";
		cout << "\t\t\t 5: Programming Project5\n";
		cout << "\t\t========================================\n";
		cout << "\t\t option: ";

		char option[80];
		cin.getline(option, 80, '\n');

		switch (atoi(option))
		{
		case 1: PracticeProgram1(); break;
		case 2: PracticeProgram3(); break;
		case 3: ProgrammingProject1(); break;
		case 4: ProgrammingProject2(); break;
		case 5: ProgrammingProject5(); break;
		default: return 0;
		}
		system("pause");
	}
	return 0;
}

void PracticeProgram1()
{
	using namespace practice_1_project_1;

	SalariedEmployee salariedEmployee1, salariedEmployee2("John", "123-45-6789", 1000);

	Administrator test, test1("John", "123-45-6789", 1000, "Director", "Production", "Jo");

	test.input(cin);
	test.print();
	test.printCheck();

	cin.ignore();
}

void PracticeProgram3()
{
	using namespace Shape_3;

	Circle c(2);
	cout << endl << c.getName() << " has radius " << c.getRadius() << " and area " << c.getArea() << ".\n";

	Rectangle r(3, 4);
	cout << endl << r.getName() << " has width " << r.getWidth()
		<< " has height " << r.getHeight()
		<< " and area " << r.getArea() << ".\n";

	cin.ignore();
}

void ProgrammingProject1()
{
	using namespace practice_1_project_1;

	Doctor test1, test2("John", "123-45-6789", 1000.00, "Pediatrician", 100.00), test3(test2);

	test1 = test3;
	test1.printCheck();
	test1.setSpecialty("Obstetrician");
	test1.setFee(120.00);
	cout << test1.getSpecialty() << " " << test1.getFee() << endl;

	cin.ignore();
}

void ProgrammingProject2()//Not testing all the member functions
{
	Person test0("Tong");
	Vehicle test1;
	Vehicle test2("Toyata", 4, test0);
	Vehicle test3(test2);

	test1 = test3;
	cout << test1;
	cout << endl;

	Truck truck1, truck2("Toyata", 4, test0, 100.10, 120), truck3(test2,110.10,120);

	truck1 = truck2;
	cout << truck1;

	cin.ignore();
}

void ProgrammingProject5()
{
	using namespace Figure_5;

	Triangle tri;
	tri.draw();
	cout << "\nDerived class Triangle object calling center().\n";
	tri.center();

	cout << "\n\n\n";


	Rectangle rect;
	rect.draw();
	cout << "\nDerived class Rectangle object calling center().\n";
	rect.center();

	cin.ignore();
}
