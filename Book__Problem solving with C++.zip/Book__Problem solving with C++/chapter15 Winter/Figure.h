#ifndef FIGURE_H
#define FIGURE_H

#include <iostream>
using namespace std;

namespace Figure_5
{
	class Figure
	{
	private:
		double x, y;//(x,y)
	public:
		virtual void erase()
		{
			cout << "\nerase() is called from the class Figure.";
		}

		virtual void draw()
		{
			cout << "\ndraw() is called from the class Figure.";
		}

		void center()
		{
			erase();
			draw();
			cout << "\ncenter() is called.";
		}
	};
}
#endif 