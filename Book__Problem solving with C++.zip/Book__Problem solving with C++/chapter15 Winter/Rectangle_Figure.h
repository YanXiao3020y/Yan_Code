#ifndef RECTANGLE_FIGURE_H
#define RECTANGLE_FIGURE_H

#include "Figure.h"

namespace Figure_5
{
	class Rectangle : public Figure
	{
	private:
		double width, height;
	public:
		void erase()
		{
			cout << "\nerase() is called from the class Rectangle.";
		}

		void draw()
		{
			cout << "\ndraw() is called from the class Rectangle.";
		}

	};
}
#endif 