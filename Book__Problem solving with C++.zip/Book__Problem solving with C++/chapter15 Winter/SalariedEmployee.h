#ifndef SALARIEDEMPLOYEE_H
#define SALARIEDEMPLOYEE_H

#include "employee.h"

namespace practice_1_project_1
{
	class SalariedEmployee : public Employee
	{
	private:
		double salary;//weekly
	public:
		SalariedEmployee(): Employee(), salary(0.0)
		{}

		SalariedEmployee(string theName, string theSSN, double theWeeklySalary) : Employee(theName, theSSN), salary(theWeeklySalary)
		{}

		SalariedEmployee(const SalariedEmployee& aSalariedEmployee) : Employee(aSalariedEmployee), salary(aSalariedEmployee.salary)
		{}

		SalariedEmployee& operator =(const SalariedEmployee& right)
		{
			Employee::operator=(right);
			salary = right.salary;
			return *this;
		}

		void setSalary(double newSalary)
		{
			salary = newSalary;
		}

		double getSalary() const
		{
			return salary;
		}

		void printCheck()
		{
			cout.setf(ios::fixed);
			cout.setf(ios::showpoint);
			cout.precision(2);

			setNetPay(salary);
			cout << "\n====================================================\n"
				<< "Pay to the order of " << getName()
				<< "\nThe sum of " << getNetPay() << " Dollars.";
			cout << "\n====================================================\n"
				<< "Check Stub NOT NEGOTIABLE! \n"
				<< "Employee Number: " << getSSN() << endl;
			cout << "Salaried Employee. Regural Pay: " << salary << " Dollars.";
			cout << "\n====================================================\n";
		}
	};

}
#endif 