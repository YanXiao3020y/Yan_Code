#ifndef DOCTOR_H
#define DOCTOR_H

#include "SalariedEmployee.h"

namespace practice_1_project_1
{
	class Doctor : public SalariedEmployee
	{
	private:
		string specialty;
		double fee;
	public:
		Doctor() : SalariedEmployee(), specialty("No specialty yet"), fee(0.0)
		{}

		Doctor(string theName, string theSSN, double theWeeklySalary, string theSpecialty, double theFee) : SalariedEmployee(theName, theSSN, theWeeklySalary), specialty(theSpecialty), fee(theFee)
		{}

		Doctor(const Doctor& aDoctor) : SalariedEmployee(aDoctor), specialty(aDoctor.specialty), fee(aDoctor.fee)
		{}

		Doctor& operator = (const Doctor& right)
		{
			SalariedEmployee::operator=(right);
			specialty = right.specialty;
			fee = right.fee;
			return *this;
		}

		void setSpecialty(string newSpecialty)
		{
			specialty = newSpecialty;
		}

		string getSpecialty() const
		{
			return specialty;
		}

		void setFee(double newFee)
		{
			fee = newFee;
		}

		double getFee() const
		{
			return fee;
		}


	};
}
#endif 