#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <iostream>
using namespace std;

namespace practice_1_project_1
{
	class Employee
	{
	private:
		string name;
		string ssn;
		double netPay;
	public:
		Employee() : name("No name yet"), ssn("No ssn yet"), netPay(0.0)
		{}
		
		Employee(string theName, string theSSN) : name(theName), ssn(theSSN), netPay(0.0)
		{}

		Employee(const Employee& aEmployee) : Employee(aEmployee.name, aEmployee.ssn)
		{
			netPay = aEmployee.netPay;
		}

		Employee& operator =(const Employee& right)
		{
			name = right.name;
			ssn = right.ssn;
			netPay = right.netPay;
			return *this;
		}

		void setName(string newName)
		{
			name = newName;
		}

		string getName() const
		{
			return name;
		}
		
		void setSSN(string newSSN)
		{
			ssn = newSSN;
		}

		string getSSN() const
		{
			return ssn;
		}

		void setNetPay(double newNetPay) 
		{
			netPay = newNetPay;
		}

		double getNetPay() const
		{
			return netPay;
		}

		void printCheck() const
		{
			cout << "\nERROR-1A: printCheck FUNCTION CALLED FOR AN UNDIFFERNTIATED EMPLOYEE. ABORTING THE PROGRAM. \nCheck with the author of the program bout this bug.\n";
			cin.ignore();
		}
	};

}

#endif