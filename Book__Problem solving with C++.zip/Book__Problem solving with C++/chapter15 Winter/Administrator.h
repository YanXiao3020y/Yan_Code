#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include "SalariedEmployee.h"

namespace practice_1_project_1
{
	class Administrator : public SalariedEmployee
	{
	private:
		string title;//e.g. Director
		string responsibility;//e.g. Production
		string supervisorName;//Administrator immediate supervisor
	protected:
		double annualSalary;
	public:
		Administrator(): SalariedEmployee(), title("No title yet"), responsibility ("No responsibility yet"), supervisorName("No supervisor name yet")
		{}

		Administrator(string theName, string theSSN, double theWeeklySalary, string theTitle, string theResponsibility, string supervisorName) : SalariedEmployee(theName, theSSN, theWeeklySalary), title(theTitle), responsibility(theResponsibility), supervisorName(supervisorName)
		{}

		void setSupervisor(string newName)
		{
			supervisorName = newName;
		}

		void input(istream& ins)
		{
			cout << "\nEnter the following information of Adminstrator: \n"
				<< "Name: ";
			string newName;
			getline(ins, newName);
			setName(newName);

			cout << "SSN: ";
			string newSSN;
			ins >> newSSN;
			setSSN(newSSN);

			cout << "Annual Salary: ";
			double newAnnualSalary;
			ins >> newAnnualSalary;
			annualSalary = newAnnualSalary;

			setSalary(annualSalary / 52);//weekly salary
			setNetPay(getSalary());

			cout << "Title: ";
			string newTitle;
			ins >> newTitle;
			title = newTitle;

			cout << "Responsibility: ";
			string newResponsibility;
			ins >> newResponsibility;
			responsibility = newResponsibility;

			cout << "Supervisor Name: ";
			string newSupervisorName;
			ins >> newSupervisorName;
			setSupervisor(newSupervisorName);
		}

		void print() const
		{
			cout << "\nName : " << getName()
				<< "\nSSN: " << getSSN()
				<< "\nWeekly salary: " << getSalary()
				<< "\nTitle: " << title
				<< "\nResponsibility: " << responsibility
				<< "\nSupervisor: " << supervisorName << endl;
		}

		void printCheck() const
		{
			cout.setf(ios::fixed);
			cout.setf(ios::showpoint);
			cout.precision(2);

			cout << "\n====================================================\n"
				<< "Pay to the order of " << getName()
				<< "\nThe sum of " << getNetPay() << " Dollars.";
			cout << "\n====================================================\n"
				<< "Check Stub NOT NEGOTIABLE! \n"
				<< "Employee Number: " << getSSN() << endl;
			cout << "Salaried Employee. Regural Pay: " << getSalary() << " Dollars.";
			cout << "\n====================================================\n"
				<< "Title: " << title
				<< "\nResponsibility: " << responsibility
				<< "\nSupervisor: " << supervisorName;
			cout << "\n====================================================\n";

		}
	};

	

}
#endif 