#ifndef TRUCK_H
#define TRUCK_H

#include "Vehicle.h"

class Truck : public Vehicle
{
private:
	double loadC;//the load capacity in tons
	int towingC;//the towing capacity in pounds
public:
	Truck() : Vehicle(), loadC(0.0), towingC(0)
	{}

	Truck(string theManufacturer, int theCylinders, Person theOwner, double theLoadC, int theTowingC): Vehicle(theManufacturer, theCylinders, theOwner), loadC(theLoadC), towingC(theTowingC)
	{}

	Truck(Vehicle aVehicle, double theLoadC, int theTowingC) : Vehicle(aVehicle), loadC(theLoadC), towingC(theTowingC)
	{}

	Truck(const Truck& theObject) : Vehicle(theObject), loadC(theObject.loadC), towingC(theObject.towingC)
	{}

	Truck& operator =(const Truck& right)
	{
		Vehicle::operator=(right);
		loadC = right.loadC;
		towingC = right.towingC;
		return *this;
	}
	
	void setLoadC(double newLoadC)
	{
		loadC = newLoadC;
	}

	double getLoadC() const
	{
		return loadC;
	}

	void setTowingC(int newTowingC)
	{
		towingC = newTowingC;
	}

	int getTowingC() const
	{
		return towingC;
	}

	friend ostream& operator << (ostream& outs, const Truck& theObject);
	
};
ostream& operator << (ostream& outs, const Truck& theObject)
{
	outs << "\nName: " << theObject.getOwner().getName()
		<< "\nManufacturer: " << theObject.getManufacturer()
		<< "\nCylinders: " << theObject.getCylinders()
		<< "\nThe load capacity: " << theObject.loadC
		<< "\nThe  towing capacity: " << theObject.towingC << endl;
	return outs;
}
#endif 