#ifndef SHAPE_H
#define SHAPE_H

#include <string>
using namespace std;

class Shape
{
private:
	string name;
public:
	Shape() : name("")
	{}

	Shape(string name)
	{
		this->name = name;
	}

	void setName(string newName)
	{
		this->name = newName;
	}

	string getName() const
	{
		return this->name;
	}

	virtual double getArea() = 0;
};

#endif 