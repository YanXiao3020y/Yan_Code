#ifndef PERSON_H
#define PERSON_H

#include <string>
#include <iostream>
using namespace std;

class Person
{
private:
	string name;
public:
	Person() : name("No name yet")
	{}

	Person(string theName) : name(theName)
	{}

	Person(const Person& theObject) : name(theObject.name)
	{}

	string getName() const
	{
		return name;
	}

	void setName(string newName)
	{
		name = newName;
	}

	Person& operator = (const Person& rtSide) 
	{
		name = rtSide.name;
		return *this;
	}

	friend istream& operator >>(istream& ins, Person& theObject)
	{
		cout << "\nEnter the name: ";
		ins >> theObject.name;
		return ins;
	}

	friend ostream& operator <<(ostream& outs, const Person& theObject)
	{
		outs << "\nName: " << theObject.name;
		return outs;
	}
};

#endif 