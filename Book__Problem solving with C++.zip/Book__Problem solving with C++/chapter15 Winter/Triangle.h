#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Figure.h"

namespace Figure_5
{
	class Triangle : public Figure
	{
	private:
		double width, height;
	public:
		void erase()
		{
			cout << "\nerase() is called from the class Triangle.";
		}

		void draw()
		{
			cout << "\ndraw() is called from the class Triangle.";
		}

	};

}
#endif 