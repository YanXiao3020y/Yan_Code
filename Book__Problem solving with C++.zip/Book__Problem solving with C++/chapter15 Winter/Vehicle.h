#ifndef VEHICLE_H
#define VEHICLE_H

#include "Person.h"

class Vehicle 
{
private:
	string manufacturer;//the name of manufacturer
	int cylinders;//the number of cylinders in the engine
	Person owner;//owner's name
public:
	Vehicle() : manufacturer("No manufacturer yet"), cylinders(0)
	{}

	Vehicle(string theManufacturer, int theCylinders, Person theOwner) : manufacturer(theManufacturer), cylinders(theCylinders)
	{
		owner.setName(theOwner.getName());
	}

	Vehicle& operator =(const Vehicle& right)
	{
		owner.setName(right.owner.getName());
		manufacturer = right.manufacturer;
		cylinders = right.cylinders;
		return *this;
	}

	Vehicle(const Vehicle& theObject) : manufacturer(theObject.manufacturer), cylinders(theObject.cylinders)
	{
		owner.setName(theObject.owner.getName());
	}

	void setManufacturer(string newManufacturer)
	{
		manufacturer = newManufacturer;
	}

	string getManufacturer() const
	{
		return manufacturer;
	}

	void setCylinders(int newCylinders)
	{
		cylinders = newCylinders;
	}

	int getCylinders() const
	{
		return cylinders;
	}

	void setOwner(Person newOwner)
	{
		owner = newOwner;
	}

	Person getOwner() const
	{
		return owner;
	}

	friend ostream& operator << (ostream& outs, const Vehicle& theObject)
	{
		outs << "\nName: " << theObject.owner.getName()
			<< "\nManufacturer: " << theObject.manufacturer
			<< "\nCylinders: " << theObject.cylinders;
		return outs;
	}

};

#endif 