//Yan Xiao
//12/25/18 (started)
//12/27/18 (finished)
//Winter practice
//Chapter 11

#include <iostream>
#include <cstring>
#include <string>

using namespace std;

void Program_Project1();
//Testing the class of VectorDouble, which is for the double of vector.

void Program_Project2();
//Testing the class of Rational, which is for rational numbers.

void Program_Project3();//incomplete
//Testing the class of Complex, which is for complex numbers.

void Program_Project4();
//Testing the class of StringVar whose values are strings.

void Program_Project11();

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\t\tChapter 11" << endl;
		cout << "\t\t=============================================" << endl;
		cout << "\t\t\t1: Programming Project1" << endl;
		cout << "\t\t\t2: Programming Project2" << endl;
		cout << "\t\t\t3: Programming Project3" << endl;
		cout << "\t\t\t4: Programming Project4" << endl;
		cout << "\t\t\t5: Programming Project11" << endl;
		cout << "\t\t=============================================" << endl;
		cout << " \t\toption: ";
		char option[80];
		cin.getline(option, 80, '\n');
		cout << endl;
		switch (atoi(option))
		{
		case 1: Program_Project1(); break;
		case 2: Program_Project2(); break;
		case 3: Program_Project3(); break;
		case 4: Program_Project4(); break;
		case 5: Program_Project11(); break;
		default: exit(0);
		}
		cout << endl;
		system("pause");
		cin.clear();
	}

	return 0;
}

namespace Vector
{
	class VectorDouble
	{
	private:
		double *arrayD;//This pointer will creat dynamic array of doubles.
		int maxCount, count;//maxCount is the size of dynamic array of doubles and count is the number of array positions currently holding values, which means maxCount is the same as the capacity of a vector and count is the same as the size of a vector.
	public:
		~VectorDouble();
		//Destructor.

		VectorDouble();
		//Initializes maxCount to 50, and creates a dynamic array for 50 elements.
		
		VectorDouble(int theMaxCount);
		// Initializes maxCount to theMaxCount, and creates a dynamic array for theMaxCount elements.

		VectorDouble(const VectorDouble& theObject);
		//Copy constructor.

		void operator =(const VectorDouble& theObject);
		//Assigns the left side equals to right side.

		friend bool operator == (const VectorDouble& left, const VectorDouble& right);
		//Returns true if the value of left equals to the value of right except maxCount. Otherwise, returns false.

		void push_back(double theValue);
		//Adds one element of double into arrayD.

		int capacity() const;
		//Returns maxCount, which is the capacity of a vector.
		
		int size() const;
		// Returns count, which is the size of a vector.

		void reserve(int theMax);
		//Increases the capacity of a vector if theMax is greater than maxCount.
		
		void resize(int theCount);
		// If theCount is greater than count, then the new elements are initialized as 0.0. Otherwise, all but the first theCount elements are lost.

		double valueAt(int index);
		// Returns the value of the index th element in the dynamic array.

		void changeValueAt(double newValue, int index);
		// Changes the double value at the index th element of the dynamic array to newValue.
		
		friend ostream& operator << (ostream& outs, const VectorDouble& theObject);//Outputs the elements of arrayD.
	};
	VectorDouble::~VectorDouble()//Destructor.
	{
		delete[] arrayD;
	}

	VectorDouble::VectorDouble() : maxCount(50), count(0)//Initializes maxCount to 50, and creates a dynamic array for 50 elements.
	{
		arrayD = new double[maxCount];
	}

	VectorDouble::VectorDouble(int theMaxCount) : maxCount(theMaxCount), count(0) // Initializes maxCount to theMaxCount, and creates a dynamic array for theMaxCount elements.
	{
		arrayD = new double[maxCount];
	}

	VectorDouble::VectorDouble(const VectorDouble& theObject) : maxCount(theObject.maxCount), count(theObject.count)//Copy constructor.
	{
		arrayD = new double[maxCount];
		for (int i = 0; i < count; i++)
			arrayD[i] = theObject.arrayD[i];
	}

	void VectorDouble::operator =(const VectorDouble& theObject)
	{
		count = theObject.count;
		if (maxCount < theObject.count)
		{
			delete[] arrayD;
			maxCount = theObject.maxCount;
			count = theObject.count;
			arrayD = new double[maxCount];
		}
		for (int i = 0; i < theObject.count; i++)
			arrayD[i] = theObject.arrayD[i];
	}

	bool operator == (const VectorDouble& left, const VectorDouble& right)//Returns true if the value of left equals to the value of right except maxCount. Otherwise, returns false.
	{
		if (left.count != right.count)
			return false;
		for (int i = 0; i < left.count; i++)
			if (left.arrayD[i] != right.arrayD[i])
				return false;
		return true;
	}

	void VectorDouble::push_back(double theValue)//Adds one element of double into arrayD.
	{
		if (count == maxCount)
		{
			maxCount *= 2;
			double *tempPtr = new double[maxCount];
			for (int i = 0; i < count; i++)
				tempPtr[i] = arrayD[i];

			delete[] arrayD;
			arrayD = tempPtr;
		}
		arrayD[count] = theValue;
		count++;
	}

	int VectorDouble::capacity() const //Returns maxCount, which is the capacity of a vector.
	{
		return maxCount;
	}

	int VectorDouble::size() const // Returns count, which is the size of a vector.
	{
		return count;
	}

	void VectorDouble::reserve(int theMax) //Increases the capacity of a vector if theMax is greater than maxCount.
	{
		if (theMax > maxCount)
			maxCount *= 2;
	}

	void VectorDouble::resize(int theCount) // If theCount is greater than count, then the new elements are initialized as 0.0. Otherwise, all but the first theCount elements are lost.
	{
		if (theCount > maxCount)
			maxCount *= 2;
		if (theCount > count)
		{
			double *tempPtr = new double[maxCount];
			for (int i = 0; i < count; i++)
				tempPtr[i] = arrayD[i];
			delete[] arrayD;
			arrayD = tempPtr;

			for (int i = count; i < theCount; i++)
				arrayD[i] = 0.0;
			count = theCount;
		}
		else if (theCount < count)
		{
			double *tempPtr = new double[maxCount];
			for (int i = 0; i < theCount; i++)
				tempPtr[i] = arrayD[i];
			delete[] arrayD;
			arrayD = tempPtr;
			count = theCount;
		}
	}

	double VectorDouble::valueAt(int index) // Returns the value of the index th element in the dynamic array.
	{
		return arrayD[index];
	}

	void VectorDouble::changeValueAt(double newValue, int index) // Changes the double value at the index th element of the dynamic array to newValue.
	{
		arrayD[index] = newValue;
	}
	ostream& operator << (ostream& outs, const VectorDouble& theObject)
	{
		for (int i = 0; i < theObject.count; i++)
			outs << theObject.arrayD[i] << " ";
		outs << endl;
		return outs;
	}
}
void Program_Project1()
{
	using namespace Vector;

	VectorDouble test1, test2(2); 

	test2.push_back(0.1);
	test2.push_back(0.2);
	test2.push_back(0.5);

	VectorDouble test3(test2);
	test1 = test3;
	cout << "test1 == test3: " << (test1 == test3 ? "Yes\n" : "No\n") << endl;

	cout << "test1: " << test1
		<< "\nSize: " << test1.size()
		<< "\nCapacity: " << test1.capacity() << endl;

	test2.reserve(6);
	test2.resize(9);
	cout << test2 << endl;
	test2.resize(2);
	cout << "test2: " << test2 << endl;

	test2.changeValueAt(1.1, 1);
	cout << "test2: " << test2 << endl;
	cout << "test2.valueAt(1): " << test2.valueAt(1) << endl;

	cin.ignore();
}

namespace Rational_number
{
	class Rational
	{
	private:
		int num[2];//num[0] represents numerator, and num[1] represents denominator.
	public:
		Rational();
		//Initializes num[0] to 0, and initiliazes num[1] to 1.

		Rational(int wholeNumber);
		//Initializes num[0] to wholeNumber, and initiliazes num[1] to 1.

		Rational(int theNumerator, int theDenominator);
		//Initializes num[0] to theNumerator, and initiliazes num[1] to theDenominator if theDenominator does not equal to 0, otherwise, initializes it to 1.

		friend istream& operator >>(istream& ins, Rational& theObject);
		//Overloads the operator >> so it can be used to input the values of type Rational. If denominator equals to 0, then it will be changed to 1.

		friend ostream& operator <<(ostream& outs, Rational& theObject);
		// Overloads the operator << so it can be used to output the values of type Rational.

		friend bool operator ==(const Rational& first, const Rational& second);
		//Overloads the operator ==. Returns true if first euqal to second, otherwise, returns false.

		friend bool operator <(const Rational& first, const Rational& second);
		//Overloads the operator <. Returns true if first is less than second, otherwise, returns false.

		friend bool operator <=(const Rational& first, const Rational& second);
		//Overloads the operator <=. Returns true if first is less than or equals to second, otherwise, returns false.

		friend bool operator >(const Rational& first, const Rational& second);
		//Overloads the operator >. Returns true if first is great than second, otherwise, returns false.

		friend bool operator >=(const Rational& first, const Rational& second);
		//Overloads the operator >=. Returns true if first is great than or equals to second, otherwise, returns false.

		friend Rational operator +(const Rational& first, const Rational& second);
		//Overloads the operator + so it can return the result that first adds second.

		friend Rational operator -(const Rational& first, const Rational& second);
		//Overloads the operator - so it can return the result that first subtracts second.

		friend Rational operator *(const Rational& first, const Rational& second);
		//Overloads the operator * so it can return the result that first multiples second.

		friend Rational operator /(const Rational& first, const Rational& second);
		//Overloads the operator / so it can return the result that first divides second.

		void normalization();
		//The denominator will be positive, and the numberator and denominator are as small sa possible.

	};
	Rational::Rational() //Initializes num[0] to 0, and initiliazes num[1] to 1.
	{
		num[0] = 0;
		num[1] = 1;
	}

	Rational::Rational(int wholeNumber)//Initializes num[0] to wholeNumber, and initiliazes num[1] to 1.
	{
		num[0] = wholeNumber;
		num[1] = 1;
	}

	Rational::Rational(int theNumerator, int theDenominator)//Initializes num[0] to theNumerator, and initiliazes num[1] to theDenominator if theDenominator does not equal to 0, otherwise, initializes it to 1.
	{
		num[0] = theNumerator;
		if (theDenominator == 0)
			num[1] = 1;
		else
			num[1] = theDenominator;
	}

	istream& operator >>(istream& ins, Rational& theObject)//Overloads the operator >> so it can be used to input the values of type Rational. If denominator equals to 0, then it will be changed to 1.
	{
		cout << "\nEnter the rational number (e.g. 1/2): ";
		ins >> theObject.num[0];
		char ch;
		cin.get(ch);
		ins >> theObject.num[1];
		if (theObject.num[1] == 0)
			theObject.num[1] = 1;
		return ins;
	}

	ostream& operator <<(ostream& outs, Rational& theObject)//Overloads the operator << so it can be used to output the values of type Rational.
	{
		theObject.normalization();
		outs << theObject.num[0] << "/" << theObject.num[1];
		return outs;
	}

	bool operator ==(const Rational& first, const Rational& second)//Overloads the operator ==. Returns true if first euqal to second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] == second.num[0] * first.num[1]);
	}

	bool operator <(const Rational& first, const Rational& second)//Overloads the operator <. Returns true if first is less than second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] < second.num[0] * first.num[1]);
	}

	bool operator <=(const Rational& first, const Rational& second)//Overloads the operator <=. Returns true if first is less than or equals to second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] <= second.num[0] * first.num[1]);
	}

	bool operator >(const Rational& first, const Rational& second)//Overloads the operator >. Returns true if first is great than second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] > second.num[0] * first.num[1]);
	}

	bool operator >=(const Rational& first, const Rational& second)//Overloads the operator >=. Returns true if first is great than or equals to second, otherwise, returns false.
	{
		return(first.num[0] * second.num[1] >= second.num[0] * first.num[1]);
	}

	Rational operator +(const Rational& first, const Rational& second)//Overloads the operator + so it can return the result that first adds second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[1] + second.num[0] * first.num[1];
		temp.num[1] = first.num[1] * second.num[1];
		return temp;
	}

	Rational operator -(const Rational& first, const Rational& second)//Overloads the operator - so it can return the result that first subtracts second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[1] - second.num[0] * first.num[1];
		temp.num[1] = first.num[1] * second.num[1];
		return temp;
	}

	Rational operator *(const Rational& first, const Rational& second)//Overloads the operator * so it can return the result that first multiples second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[0];
		temp.num[1] = first.num[1] * second.num[1];
		return temp;
	}

	Rational operator /(const Rational& first, const Rational& second)//Overloads the operator / so it can return the result that first divides second.
	{
		Rational temp;
		temp.num[0] = first.num[0] * second.num[1];
		temp.num[1] = first.num[1] * second.num[0];
		return temp;
	}

	void Rational::normalization()//The denominator will be positive, and the numberator and denominator are as small sa possible.
	{
		if (num[1] < 0)
		{
			num[1] = -num[1];
			num[0] = -num[0];
		}
		for (int i = 2; i < 100; i++)
			if (num[0] % i == 0 && num[1] % i == 0)
			{
				num[0] /= i;
				num[1] /= i;
				i--;
			}
	}
}
void Program_Project2()
{
	using namespace Rational_number;

	Rational test1, test2(2);
	cout << "\nThe first rational number: ";
	cin >> test1;
	cout << "\nThe second rational number: ";
	cin >> test2;

	cout << "\nFirst: " << test1 << endl;
	cout << "Second: " << test2 << endl << endl;

	Rational result(1,0);

	//Addition
	result = test1 + test2;
	cout << test1 << " + " << test2 << " = " << result << endl;

	//Subtraction
	result = test1 - test2;
	cout << test1 << " - " << test2 << " = " << result << endl;

	//Multiplication
	result = test1 * test2;
	cout << test1 << " * " << test2 << " = " << result << endl;

	//Division
	result = test1 / test2;
	cout << test1 << " / " << test2 << " = " << result << endl << endl;

	cout << "First == Second: " << (test1 == test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First < Second: " << (test1 < test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First > Second: " << (test1 > test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First <= Second: " << (test1 <= test2 ? "Yes.\n" : "No.\n") << endl;
	cout << "First >= Second: " << (test1 >= test2 ? "Yes.\n" : "No.\n") << endl;

	cin.ignore();
}

namespace Complex_number
{
	class Complex
	{
		//incomplete

	};
}
void Program_Project3()
{
	using namespace Complex_number;

	//incomplete

	cin.ignore();
}

namespace String_var
{
	class StringVar
	{
	private:
		char *value;//Pointer to dynamic array that holds the string value.
		int maxLength;//Declared max length of any string value.
	public:
		~StringVar();
		//Returns all the dynamic memory used by the object to the freestore.

		StringVar(int size);
		//Initializes the object so it can accept string values up to size in length. And sets the value of the object equal to the empty string.

		StringVar();
		//Initializes the object so it can accept string values of length 100 or less. And Sets the value of the object equal to the empty string.

		StringVar(const char a[]);
		//Initializes the object so its value is the string stored in a and so that it can later be set to string values up to strlen(a) in length.

		StringVar(const StringVar& stringObject);
		//Copy constructor

		int length() const;
		//Returns the length of the current string value.

		void inputLine(istream& ins);
		//The next text in the input stream ins, up to '\n', is copied to the calling object. If there is not sufficient room, then only as much as will fit is copied.
		
		friend ostream& operator <<(ostream& outs, const StringVar& theString);
		//Overloads the << operator so it can be used to output values of type StringVar.

		StringVar copyPiece(int index, int length);
		//Returns a specified substring where index is started point.

		char oneChar(int index);
		//Returns a specified single character at index.

		void setChar(int index, char theChar);
		//Changes a specified character.

		void operator =(const StringVar& right);
		//Overloads the assignment operator.

		friend bool operator ==(const StringVar& first, const StringVar& second);
		//Overloads the == operator. Returns true if both strings are the same, otherwise, returns false.

		friend StringVar operator +(const StringVar& first, const StringVar& second);
		//Overloads the + operator to perform concatenation of strings of type StringVar.

		friend istream& operator >> (istream& ins, const StringVar& theObject);
		//Overloads the >> operator to read one word.
		
	};
	StringVar::~StringVar()//Returns all the dynamic memory used by the object to the freestore.
	{
		delete[] value;
	}

	StringVar::StringVar(int size) : maxLength(size)//Initializes the object so it can accept string values up to size in length. And sets the value of the object equal to the empty string.
	{
		value = new char[maxLength + 1];
		value[0] = '\0';
	}

	StringVar::StringVar() : maxLength(100)//Initializes the object so it can accept string values of length 100 or less. And Sets the value of the object equal to the empty string.
	{
		value = new char[maxLength + 1];
		value[0] = '\0';
	}

	StringVar::StringVar(const char a[]) : maxLength(strlen(a))//Initializes the object so its value is the string stored in a and so that it can later be set to string values up to strlen(a) in length.
	{
		value = new char[maxLength + 1];
		strcpy_s(value, maxLength + 1, a);
	}

	StringVar::StringVar(const StringVar& stringObject) : maxLength(strlen(stringObject.value))//Copy constructor
	{
		value = new char[maxLength + 1];
		strcpy_s(value, maxLength + 1, stringObject.value);
	}

	int StringVar::length() const //Returns the length of the current string value.
	{
		return strlen(value);
	}


	void StringVar::inputLine(istream& ins)//The next text in the input stream ins, up to '\n', is copied to the calling object. If there is not sufficient room, then only as much as will fit is copied.
	{
		ins.getline(value, maxLength + 1);
	}

	ostream& operator <<(ostream& outs, const StringVar& theString)//Overloads the << operator so it can be used to output values of type StringVar.
	{
		outs << theString.value;
		return outs;
	}

	StringVar StringVar::copyPiece(int index, int length)//Returns a specified substring where index is started point.
	{
		StringVar temp(length);
		int indexOfPiece = 0;
		for (int i = index; i < length + index; i++)
			if (i < strlen(value))
				temp.value[indexOfPiece++] = value[i];

		temp.value[indexOfPiece] = '\0';
		return temp;
	}

	char StringVar::oneChar(int index)//Returns a specified single character at index.
	{
		return value[index];
	}

	void StringVar::setChar(int index, char theChar)//Changes a specified character.
	{
		if (index < maxLength)
			value[index] = theChar;
		else
			cout << "ERROR-4A: index is out of bound!\n";
	}

	void StringVar::operator =(const StringVar& right)//Overloads the assignment operator.
	{
		if (maxLength < strlen(right.value))
		{
			delete[] value;
			maxLength = strlen(right.value);
			value = new char[maxLength + 1];
		}
		strcpy_s(value, maxLength + 1, right.value);
	}

	bool operator ==(const StringVar& first, const StringVar& second)//Overloads the == operator. Returns true if both strings are the same, otherwise, returns false.
	{
		if (first.length() != second.length())
			return false;
		for (int i = 0; i < first.length(); i++)
			if (first.value[i] != second.value[i])
				return false;
		return true;
	}

	StringVar operator +(const StringVar& first, const StringVar& second)//Overloads the + operator to perform concatenation of strings of type StringVar.
	{
		StringVar temp(first.length() + second.length());
		strcpy_s(temp.value, first.length() + 1, first.value);
		strcat_s(temp.value, temp.maxLength + 1, second.value);
		return temp;
	}

	istream& operator >> (istream& ins, const StringVar& theObject)//Overloads the >> operator to read one word.
	{
		ins >> theObject.value;
		return ins;
	}
}
void Program_Project4()
{
	using namespace String_var;

	char a[] = "Hello!";
	StringVar test1, test2(5), test3(a), test4(test3);

	cout << "\nEnter a string: ";
	test1.inputLine(cin);
	cout << "test1: " << test1
		<< "\ntest1.length(): " << test1.length() << endl;

	test1 = test3.copyPiece(3, 6);
	cout << "test1: " << test1 << endl;
	test1.setChar(2, 'H');
	cout << "test1.oneChar(2): " << test1.oneChar(2) << endl;
	cout << "test1: " << test1 << endl;

	cout << "test4: " << test4 << endl;
	cout << "test1 == test4: " << (test1 == test4 ? "Yes.\n" : "No.\n");

	test3 = test1 + test4;
	cout << "test1 + test4 = " << test3 << endl;

	cout << "\nEnter a word: ";
	cin >> test1;
	cout << "test1: " << test1 << endl;


	cin.ignore();
}

namespace Project11
{
	class String
	{
	private:
		string *dynamicS;
		int size;
	public:
		~String();
		//A destructor that frees up the memory allocated to the dynamic array.
		
		String();
		//A default constructor which initializes the size to 0.
		
		String(int theSize);
		//A constructor which initializes the size up to theSize.

		String(const String& theObject);
		//A copy constructor.

		void operator =(const String& right);
		//Overloads the assignment operator.

		void addEntry(string newEntry);
		//Adds the new entry onto the end of the array, increment size.

		void deleteEntry(string entryToDelete);
		//Search dynamicArray for entryToDelete. If not found, return the unmodified dynamicArray. Decreses size by 1, copys all elements except entryToDelete into the array.

		int sizeOf() const;
		//Returns the current size of the array.

		void setItem(int index, string theItem);
		//Sets a specific item in the array.

		string getItem(int index) const;
		//Gets a specific item in the array.

		friend ostream& operator << (ostream& outs, const String& theObject);//Overloads the << operator so it can output the values of type String.
		
	};
	String::~String() //A destructor that frees up the memory allocated to the dynamic array.
	{
		delete[] dynamicS;
	}

	String::String() : size(0) //A default constructor which initializes the size to 0.
	{
		dynamicS = new string[size];
	}

	String::String(int theSize) : size(theSize) //A constructor which initializes the size up to theSize.
	{
		dynamicS = new string[size];
	}

	String::String(const String& theObject) : size(theObject.size)//A copy constructor.
	{
		dynamicS = new string[size];
		for (int i = 0; i < size; i++)
			dynamicS[i] = theObject.dynamicS[i];
	}

	void String::operator =(const String& right)//Overloads the assignment operator.
	{
		if (size < right.size)
		{
			delete[] dynamicS;
			size = right.size;
			dynamicS = new string[size];
		}
		size = right.size;
		for (int i = 0; i < size; i++)
			dynamicS[i] = right.dynamicS[i];
	}

	void String::addEntry(string newEntry)//Adds the new entry onto the end of the array, increment size.
	{
		String temp(++size);
		for (int i = 0; i < size - 1; i++)
			temp.dynamicS[i] = dynamicS[i];

		delete[] dynamicS;
		temp.dynamicS[size - 1] = newEntry;
		dynamicS = new string[temp.size];
		for (int i = 0; i < size; i++)
			dynamicS[i] = temp.dynamicS[i];
	}

	void String::deleteEntry(string entryToDelete)//Search dynamicArray for entryToDelete. If not found, return the unmodified dynamicArray. Decreses size by 1, copys all elements except entryToDelete into the array.
	{
		bool found = false;
		for (int i = 0; i < size; i++)
			if (dynamicS[i] == entryToDelete)
			{
				found = true;
				break;
			}

		if (found)
		{
			String temp(--size);
			int index = 0;
			for (int i = 0; i < size + 1; i++)
				if (dynamicS[i] != entryToDelete)
					temp.dynamicS[index++] = dynamicS[i];

			delete[] dynamicS;
			dynamicS = new string[temp.size];
			for (int i = 0; i < size; i++)
				dynamicS[i] = temp.dynamicS[i];
		}
	}

	int String::sizeOf() const//Returns the current size of the array.
	{
		return size;
	}

	void String::setItem(int index, string theItem)//Sets a specific item in the array.
	{
		dynamicS[index] = theItem;
	}

	string String::getItem(int index) const //Gets a specific item in the array.
	{
		return dynamicS[index];
	}

	ostream& operator << (ostream& outs, const String& theObject)
	{
		for (int i = 0; i < theObject.size; i++)
			outs << theObject.dynamicS[i] << " ";
		outs << endl;
		return outs;
	}
}
void Program_Project11()
{
	using namespace Project11;

	String test1;

	test1.addEntry("Hello!");
	test1.addEntry("Hey!");
	test1.addEntry("Hy!");

	test1.addEntry("You!");
	cout << "test1: " << test1;

	String test2(test1);

	test2.deleteEntry("Hello");
	cout << "test2: " << test2;

	test2.deleteEntry("Hey!");
	cout << "test2: " << test2;

	test2.setItem(1, "Haha!");
	cout << "test2.getItem(1):" << test2.getItem(1) << endl;
	cout << "test2: " << test2
		<< "test2.sizeOf(): " << test2.sizeOf() << endl;

	String test3;
	test3 = test1;
	cout << "test3: " << test3;

	test1 = test2;
	cout << "test1: " << test1;

	cin.ignore();
}