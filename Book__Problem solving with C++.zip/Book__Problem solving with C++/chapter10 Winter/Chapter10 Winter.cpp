//Yan Xiao
//12/21/2018 (started)
//12/23/2018 (finished)
//Winter Practice
//Chapter 10

#include <iostream>
#include <iomanip>
#include <string>
#include "Input.h"

using namespace std;
using namespace Validation;

void Program_Project1();
//This program will read in the student's scores and output the student's record, which consists of two quiz and two exam scores as well as the student's average numeric score for the entire course and the final letter grade.
//Only use a structure.

void Program_Project2();
//The same as Program_Project1, but use a class.

void Program_Project7();
//Testing for a Rational number class, which contains functions add, sub, mul, div, less, equal, neg, input, output and its constructors. 

void Program_Project8();
//Testing for a class Odometer that will be usedd to track fuel and mileage for an automotive vehicle.

void Program_Project11();
//Testing for a class Movie that contains information about a movie.

int main()
{
	while (true)
	{
		system("cls");
		cout << "\n\t\t\tChapter 10" << endl;
		cout << "\t=========================================" << endl;
		cout << " \t\t1: Programming Project1" << endl;
		cout << " \t\t2: Programming Project2" << endl;
		cout << " \t\t3: Programming Project7" << endl;
		cout << " \t\t4: Programming Project8" << endl;
		cout << " \t\t5: Programming Project11" << endl;
		cout << "\t=========================================" << endl;
		cout << " \toption: ";
		char option[80];
		cin.getline(option, 80, '\n');
		cout << endl;
		switch (atoi(option))
		{
		case 1: Program_Project1(); break;
		case 2: Program_Project2(); break;
		case 3: Program_Project7(); break;
		case 4: Program_Project8(); break;
		case 5: Program_Project11(); break;
		default: exit(0);
		}
		cout << endl;
		system("pause");
		cin.clear();
	}

	return 0;
}

struct GradesOfStruct
{
	double final, midterm, quiz1, quiz2;
	double average;
	char letterGrade;
};
void Program_Project1()//Using pointer
{
	//with pointer
	int size = inputInteger("\nEnter the number of students: ", cin, true, 0);
	GradesOfStruct *test = new GradesOfStruct[size];

	//Inputs
	for (int i = 0; i < size; i++)
	{
		cout << "\nStudent " << i + 1 << ":\n";
		test[i].final = inputInteger("\nEnter the final score: ", cin, 0, 100);;
		test[i].midterm = inputInteger("\nEnter the midterm score: ", cin, 0, 100);
		test[i].quiz1 = inputInteger("\nEnter the first quiz score: ", cin, 0, 10);
		test[i].quiz2 = inputInteger("\nEnter the second quiz score: ", cin, 0, 10);
	}
	
	//Calculate
	for (int i = 0; i < size; i++)
		test[i].average = (test[i].final / 100 * .5 + test[i].midterm / 100 * .25 + (test[i].quiz1 + test[i].quiz2) / 20 * .25) * 100;

	//Judge
	for (int i = 0; i < size; i++)
	{
		if (test[i].average >= 90)
			test[i].letterGrade = 'A';
		else if (test[i].average >= 80)
			test[i].letterGrade = 'B';
		else if (test[i].average >= 70)
			test[i].letterGrade = 'C';
		else if (test[i].average >= 60)
			test[i].letterGrade = 'D';
		else 
			test[i].letterGrade = 'F';
	}

	//Outputs
	cout << "\n\n\n";
	cout << left << setw(10) << "students " 
		<< left << setw(10) << "Final"
		<< left << setw(10) << "Midterm"
		<< left << setw(10) << "Quiz1"
		<< left << setw(10) << "Quiz2"
		<< left << setw(10) << "Average"
		<< left << setw(10) << "Letter Grade"
		<< endl;
	for (int i = 0; i < size; i++)
	{
		cout << "   "<< left << setw(10) << i + 1
			<< left << setw(10) << test[i].final
			<< left << setw(10) << test[i].midterm
			<< left << setw(10) << test[i].quiz1
			<< left << setw(10) << test[i].quiz2
			<< left << setw(10) << test[i].average 
			<< left << setw(10) << test[i].letterGrade
			<< endl;
	}

	delete[] test;

	//cout << "==============================================================================================";
	////Without pointer
	//Grades test;

	////Inputs
	//test.final = inputInteger("\nEnter your final score: ", 0, 100);
	//test.midterm = inputInteger("\nEnter your midterm score: ", 0, 100);
	//test.quiz1 = inputInteger("\nEnter your first quiz score: ", 0, 10);
	//test.quiz2 = inputInteger("\nEnter your second quiz score: ", 0, 10);
	//

	////Calculate
	//test.average = (test.final / 100 * .5 + test.midterm / 100 * .25 + (test.quiz1 + test.quiz2) / 20 * .25) * 100;

	////Judge
	//	if (test.average >= 90)
	//		test.letterGrade = 'A';
	//	else if (test.average >= 80)
	//		test.letterGrade = 'B';
	//	else if (test.average >= 70)
	//		test.letterGrade = 'C';
	//	else if (test.average >= 60)
	//		test.letterGrade = 'D';
	//	else
	//		test.letterGrade = 'F';

	////Outputs
	//cout << "\n\n\n";
	//
	//cout << left << setw(10) << "Final"
	//	<< left << setw(10) << "Midterm"
	//	<< left << setw(10) << "Quiz1"
	//	<< left << setw(10) << "Quiz2"
	//	<< left << setw(10) << "Average" 
	//	<< left << setw(10) << "Letter Grade"
	//	<< endl;
	//	 
	//cout << "  "<< left << setw(10) << test.final
	//	<< left << setw(10) << test.midterm
	//<< left << setw(10) << test.quiz1
	//<< left << setw(10) << test.quiz2
	//<< left << setw(10) << test.average 
	//<< left << setw(10) << test.letterGrade
	//	<< endl;

	cin.ignore();
}

class GradesOfClass
{
private:
	double final, midterm, quiz1, quiz2;
	double average;
	char letterGrade;
public:
	GradesOfClass() : final(0.0), midterm(0.0), quiz1(0.0), quiz2(0.0), average(0.0), letterGrade('F')//default constructor
	{}

	GradesOfClass(double theFinal, double theMidterm, double theQuiz1, double theQuiz2) : final(theFinal), midterm(theMidterm), quiz1(theQuiz1), quiz2(theQuiz2), average(0.0), letterGrade('F')
	{}

	void setFinal(double newFinal)//Sets final to newFinal.
	{
		final = newFinal;
	}

	double getFinal() const //Retrieves the data from final.
	{
		return final;
	}

	void setMidterm(double newMiderm)
	{
		midterm = newMiderm;
	}

	double getMidterm() const
	{
		return midterm;
	}

	void setQuiz1(double newQuiz1)
	{
		quiz1 = newQuiz1;
	}

	double getQuiz1() const
	{
		return quiz1;
	}

	void setQuiz2(double newQuiz2)
	{
		quiz2 = newQuiz2;
	}

	double getQuiz2() const
	{
		return quiz2;
	}

	double getAverage() const
	{
		return average;
	}

	char getLetterGrade() const
	{
		return letterGrade;
	}

	void calculation()//Calculates average.
	{
		average = (final / 100 * .5 + midterm / 100 * .25 + (quiz1 + quiz2) / 20 * .25) * 100;
	}

	void studentLetterGrade()//Calculates letterGrade according to average.
	{
			if (average >= 90)
				letterGrade = 'A';
			else if (average >= 80)
				letterGrade = 'B';
			else if (average >= 70)
				letterGrade = 'C';
			else if (average >= 60)
				letterGrade = 'D';
			else
				letterGrade = 'F';
	}

	void output(ostream& out)
	{
		out << "\n\n\n";
		 
		out << "  " << left << setw(10) << "Final"
			<< left << setw(10) << "Midterm"
			<< left << setw(10) << "Quiz1"
			<< left << setw(10) << "Quiz2"
			<< left << setw(10) << "Average"
			<< left << setw(10) << "Letter Grade"
			<< endl;
	}
};
void Program_Project2()
{
	GradesOfClass test;

	//Inputs
	test.setFinal(inputInteger("\nEnter your final score: ", cin, 0, 100));
	test.setMidterm(inputInteger("\nEnter your midterm score: ", cin, 0, 100));
	test.setQuiz1(inputInteger("\nEnter your first quiz score: ", cin, 0, 10));
	test.setQuiz2(inputInteger("\nEnter your second quiz score: ", cin, 0, 10));


	//Calculates
	test.calculation();

	//Judges for letter grade.
	test.studentLetterGrade();

	//Outputs
	test.output(cout);
	cout << "   " << left << setw(10)
		<< left << setw(10) << test.getFinal()
		<< left << setw(10) << test.getMidterm()
		<< left << setw(10) << test.getQuiz1()
		<< left << setw(10) << test.getQuiz2()
		<< left << setw(10) << test.getAverage()
		<< left << setw(10) << test.getLetterGrade()
		<< endl;
	cin.ignore();
}

class Rational
{
private:
	int numerator, denominator;
public:
	Rational() : numerator(0), denominator(1)//Default constructor. Initializes numerator to 0 and denominator to 1.
	{}

	Rational(int theNumerator, int theDenominator) : numerator(theNumerator)//Initializes numerator to theNumerator and denominator to theDenominator when denominator does not equal to 0. Otherwise, initializes it to 1. 
	{
		theDenominator == 0 ? denominator = 1 : denominator = theDenominator;
	}

	Rational(int theNumerator) : numerator(theNumerator), denominator(1)//Initializes numerator to theNumerator and denominator to 1.
	{}

	void input(istream& ins)//Inputs numerator and denominator.
	{
		do
		{
			cout << "\nEnter the rational number (e.g. 1/2): ";
			numerator = inputInteger(ins, "\nEnter the rational number (e.g. 1/2): ");
			char symbol;
			cin.get(symbol);
			denominator = inputInteger(ins, "\nEnter the rational number (e.g. 1/2): ");
			
			if (denominator == 0)
				cout << "\nERROR-1A: Denominator cannot equal to 0!\n";

		} while (denominator == 0);

	}

	void output(ostream& outs)//Outputs the rational number (e.g. 1/2)
	{
		normalize();
		cout << numerator << "/" << denominator;
	}

	Rational add(Rational second)//Addition
	{
		Rational temp;
		
		temp.numerator = numerator * second.denominator + denominator * second.numerator;
		temp.denominator = denominator * second.denominator;

		return temp;
	}

	Rational sub(Rational second)//Subtract
	{
		Rational temp;

		temp.numerator = numerator * second.denominator - denominator * second.numerator;
		temp.denominator = denominator * second.denominator;

		return temp;
	}

	Rational mul(Rational second)//Multiplication
	{
		Rational temp;

		temp.numerator = numerator * second.numerator;
		temp.denominator = denominator * second.denominator;

		return temp;
	}

	Rational div(Rational second)//Division
	{
		Rational temp;

		temp.numerator = numerator * second.denominator;
		temp.denominator = second.numerator * denominator;

		return temp;
	}

	Rational neg()//Return the negative of the calling object.
	{
		Rational temp;

		temp.numerator = -numerator;
		temp.denominator = denominator;

		return temp;
	}

	bool less(Rational second)//Checks whether the calling object is less than second.
	{
		return (numerator * second.denominator < second.numerator * denominator);
	}

	bool equal(Rational second)//Checks whether the calling object equals second.
	{
		return (numerator * second.denominator == second.numerator * denominator);
	}

	void normalize()//Lets any sign be carried by the numberator and keeps the denominator positive.
	{
		if (denominator < 0)
		{
			numerator = -numerator;
			denominator = -denominator;
		}
	}
};
void Program_Project7()
{
	Rational r1, r2(0, 0);
	
	cout << "\nThe first rational number: ";
	r1.input(cin);

	cout << "\nThe second rational number: ";
	r2.input(cin);

	cout << "\n\n";
	Rational result(2);

	//Addition
	result = r1.add(r2);
	r1.output(cout);
	cout << " + ";
	r2.output(cout);
	cout << " = ";
	result.output(cout);
	cout << endl;

	//Subtract
	result = r1.sub(r2);
	r1.output(cout);
	cout << " - ";
	r2.output(cout);
	cout << " = ";
	result.output(cout);
	cout << endl;

	//Multiplication
	result = r1.mul(r2);
	r1.output(cout);
	cout << " * ";
	r2.output(cout);
	cout << " = ";
	result.output(cout);
	cout << endl;

	//Division
	result = r1.div(r2);
	r1.output(cout);
	cout << " / ";
	r2.output(cout);
	cout << " = ";
	result.output(cout);
	cout << endl;

	//Negative
	result = r1.neg();
	cout << " -( ";
	r1.output(cout);
	cout << ") ";
	cout << " = (";
	result.output(cout);
	cout << ") ";
	cout << endl;

	//Less than
	cout << "(";
	r1.output(cout);
	cout << ") < ";
	cout << "(";
	r2.output(cout);
	cout << ") ? " << (r1.less(r2) ? "Yes.\n" : "No.\n");
	cout << endl;

	//equality
	cout << "(";
	r1.output(cout);
	cout << ") == ";
	cout << "(";
	r2.output(cout);
	cout << ") ? " << (r1.equal(r2) ? "Yes.\n" : "No.\n");
	cout << endl;

	cin.ignore();
}

class Odometer
{
private:
	double milesDriven, fuelEfficiency;//Unit: for fuelEfficiency is in miles per gallon.
public:
	Odometer() : milesDriven (0.0), fuelEfficiency(0.0)//Initializes milesDriven and fuelEfficiency to zero.
	{}

	void reset()//Resets the odometer to zero miles.
	{
		milesDriven = 0.0;
		fuelEfficiency = 0.0;
	}

	void setFuelEfficiency(double newFuelEfficiency)
	{
		fuelEfficiency = newFuelEfficiency;
	}

	double getFuelEfficiency() const
	{
		return fuelEfficiency;
	}

	void addMilesDriven(double newMilesDriven)//Accepts miles driven for a trip and adds it to the odometer's total.
	{
		milesDriven += newMilesDriven;
	}

	double getMileDriven() const
	{
		return milesDriven;
	}
	double calculate() //Returns the number of gallons of gasonline that the vehicle has consumed since the odometer was last reset.
	{
		return (milesDriven / fuelEfficiency);
	}

};
void Program_Project8()
{
	//with pointer
	int size = inputInteger("\nEnter the number of trips: ", cin, 0);
	Odometer *test = new Odometer[size];

	for (int i = 0; i < size; i++)
	{
		test[i].setFuelEfficiency(inputInteger("\nEnter the fuel efficiency: ", cin, true, 0));
		char ans;
		do
		{
			test[i].addMilesDriven(inputInteger("\nAdd miles driven: ", cin, true));
			cout << "\nDo you want to add more miles (Y/N): ";
			cin >> ans;
			cin.ignore();
		} while (tolower(ans) == 'y');
		cout << "\n=======================================================================";
		cout << "\n\nThe fuel efficiency: " << test[i].getFuelEfficiency() << " miles per gallon.\n"
			<< "\nThe total odometer: " << test[i].getMileDriven() << " miles.\n";
		cout << "\nThe number of gallons of gasonline that the vehicle has consumed since the odometer was last reset is " << test[i].calculate() << ".\n\n";
		cout << "=======================================================================\n";

		test[i].reset();
	}

	delete[] test;

	////without pointer
	//Odometer test;

	//	test.setFuelEfficiency(inputInteger("\nEnter the fuel efficiency: ", cin, true, 0));
	//	char ans;
	//	do
	//	{
	//		test.addMilesDriven(inputInteger("\nAdd miles driven: ", cin, true));
	//		cout << "\nDo you want to add more miles (Y/N): ";
	//		cin >> ans;
	//		cin.ignore();
	//	} while (tolower(ans) == 'y');
	//	cout << "\nThe number of gallons of gasonline that the vehicle has consumed since the odometer was last reset is " << test.calculate() << ".\n";
	//	test.reset();

	cin.ignore();
}

class Movie
{
private:
	string name, MPAARating;
	int terrible, bad, ok, good, great;//Each represents the number of people
public:
	Movie() : name("No Name Yet"), MPAARating("No MPAA rating Yet"), terrible(0), bad(0), ok(0), good(0), great(0)//Default constructor. 
	{}

	Movie(string theName, string theMPAARating) : name(theName), MPAARating(theMPAARating), terrible(0), bad(0), ok(0), good(0), great(0)//Initializes name to theName and MPAARating to theMPAARating.
	{}

	void setName(string newName)
	{
		name = newName;
	}

	string getName() const
	{
		return name;
	}

	void setMPAARating(string newMPAARating)
	{
		MPAARating = newMPAARating;
	}

	string getMPAARating() const
	{
		return MPAARating;
	}

	void addRating(int rating)
	{
		if (rating < 1 || rating>5)
		{
			cout << "ERROR-1A: Invalid input. The rating should between 1 to 5.\n";
			return;
		}

		switch (rating)
		{
		case 1: terrible++; break;
		case 2: bad++; break;
		case 3: ok++; break;
		case 4: good++; break;
		case 5: great++; break;
		}
	}

	double getAverage() const
	{
		int numberOfPeople = terrible + bad + ok + good + great;
		double totalRatings = terrible * 1 + bad * 2 + ok * 3 + good * 4 + great * 5;

		return (totalRatings / numberOfPeople);
	}
};
void Program_Project11()
{
	int size = inputInteger("\nEnter the number of movie: ", cin, true, 0);
	Movie *test1 = new Movie[size];
	Movie *test2 = new Movie("Superman", "G");
	
	for (int i = 0; i < size; i++)
	{
		//Moive name
		if (size > 1)
			cout << "\nEnter the movie " << i + 1 << "'s name: ";
		else
			cout << "\nEnter the movie's name: ";
		string name;
		cin >> name;
		test1[i].setName(name);

		//MPAARating
		if (size > 1)
			cout << "\nEnter the MPAARating " << i + 1 << " (e.g. G, PG, PG-13, R): ";
		else
			cout << "\nEnter the MPAARating (e.g. G, PG, PG-13, R): ";
		string MPAARating;
		cin >> MPAARating;
		test1[i].setMPAARating(MPAARating);

		int count = 1;
		char ans = 'y';
		cout << "\n**********************************************************";
		cout << "\nPlease enter at least five ratings for this movies!\n";
		cout << "**********************************************************\n";

		//ratings
		do
		{
			test1[i].addRating(inputInteger("\nEnter the rating for this movie: ", cin, 1, 5));
			count++;
			if (count > 5)
			{
				cout << "\nDo you want to continue (Y/N): ";
				cin >> ans;
			}
		} while (tolower(ans) == 'y');

		//outputs
		cout << "\nMovie: " << test1[i].getName() << endl
			<< "MPAA rating: " << test1[i].getMPAARating() << endl
			<< "Average rating: " << test1[i].getAverage() << "\n";

		cout << "=====================================================\n\n";
	}


	delete[] test1;//Releases memory.
	delete test2;

	cin.ignore();
}